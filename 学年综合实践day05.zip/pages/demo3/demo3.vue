<template>
	<view>
		<!-- 访问chatGPT的接口 -->
		<view class="btn" @click="getData">按钮</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {

			}
		},
		methods: {
			getData() {
				uni.request({
					url: "https://api.openai.com/v1/completions",
					method: "POST",
					header: {
						'Content-Type': 'application/json',
						// 需要把 Bearer 后面的密钥 换成你自己的密钥
						'Authorization': `Bearer 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`
					},
					data: {
						model: "text-davinci-003",
						prompt: "你好",
						max_tokens: 100, // 生成文本的最大长度
						n: 1, // 生成的文本数量
						temperature: 0.7 // 控制生成文本的创造力，值越高越创造性
					},
					success(res) {
						console.log(res);
					}
				})
			}
		}
	}
</script>

<style>
	.btn {
		width: 100px;
		height: 50px;
		border-radius: 10px;
		text-align: center;
		line-height: 50px;
		background-color: pink;
		font-size: 20px;
		font-weight: bold;
	}
</style>