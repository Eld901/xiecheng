<template>
	<view>
		<!-- 
		  vue指令
		     1.v-bind 数据绑定  
			   格式：组件属性   v-bind:属性="变量"  简写  :属性="变量"
			        组件内容    {{变量}}
					
				注意：变量应该写在  data的return
				
			2.事件
			  1.事件源
			  2.事件
			  3.事件处理函数
			  
			  v-on 绑定事件 简写  @click="函数名"
			  注意：函数 需要写在  methods对象里面
			  
			  
			3.v-for  列表循环  v-for="(item,index) in 数组"
			
			4.v-if v-else  条件渲染  v-if="变量"
		 -->
		 <!-- 
		   内置API
		   1.uni.showToast   提示框
		   
		   2.uni.showLoading  加载框（需要调用 uni.hideLoading才会消失）
		     uni.hideLoading  隐藏加载框
			 
			 setTimeout(function(){},2000)  第一个参数表示执行函数  第二个参数表示多少毫秒后 执行第一个参数
			 
			 
		   3.uni.showModel   模态框（确认和取消的按钮）
		   
		   
		   4.uni.setStorage  设置缓存
		     uni.getStorage  获取缓存
		  -->
		  <!-- 
		   生命周期
		     onload()   页面加载  小程序显示 并且打开页面  只会执行一次
		     onshow()   页面显示  当前页面显示出来 都会触发
			 onready()  页面加载完毕   只会执行一次
			 onhide()   页面隐藏  当前页面被隐藏时会触发
		   -->
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			}
		},
		methods: {
			
		}
	}
</script>

<style>

</style>
