<template>
	<view>
		<view class="btn" @click="getData">按钮</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {

			}
		},
		methods: {
			getData() {
				uni.request({
					url: "/api",
					method: "GET",
					data: {
						key: "free",
						appid: 0,
						msg: "你好"
					},
					success(res) {
						console.log(res);
					}
				})
			}
		}
	}
</script>

<style>
	.btn {
		width: 100px;
		height: 50px;
		border-radius: 10px;
		text-align: center;
		line-height: 50px;
		background-color: pink;
		font-size: 20px;
		font-weight: bold;
	}
</style>