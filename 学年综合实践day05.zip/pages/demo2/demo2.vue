<template>
	<view>
		<!-- 网络请求 -->
		<view class="btn" @click="getData">按钮</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			}
		},
		methods: {
			getData(){
				// console.log(1111);
				// 发送网络请求  uni.request()
				
				uni.request({
					// 代表我要访问  http://127.0.0.1:7001这个服务器 里面的 /chat  这个接口
					url:"/api/chat",
					// 请求的方式  GET
					method:"GET",
					// 成功的回调函数  res 服务器返回的数据对象
					success(res) {
						console.log(res);
					}
				})
			}
		}
	}
</script>

<style>
    .btn {
		width: 100px;
		height: 50px;
		border-radius: 10px;
		text-align: center;
		line-height: 50px;
		background-color: pink;
		font-size: 20px;
		font-weight: bold;
	}
</style>
