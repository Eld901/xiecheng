<template>
	<view>
		<!-- 
		  scroll-view 可滚动区域 
		  属性：
		      1.scroll-x  允许横向滚动
			  2.scroll-y  允许纵向滚动
		  注意：
		     1.子元素的高度/宽度要超过 scroll-view的高度/宽度
		 -->
		 <!-- 
		   控制滚动条消失：
		    1.需要在App.vue这个文件里面的  style属性 增加如下样式
			::-webkit-scrollbar {
				width: 0;
				height: 0;
				background-color: transparent;
				display: none;
			}
		  -->
		 <!-- 竖向滚动 -->
		 <scroll-view class="fa" scroll-y>
			 <view class="son"></view>
			 <view class="son"></view>
			 <view class="son"></view>
			 <view class="son"></view>
			 <view class="son"></view>
			 <view class="son"></view>
			 <view class="son"></view>
			 <view class="son"></view>
			 <view class="son"></view>
			 <view class="son"></view>
		 </scroll-view>
		 <!-- 横向滚动 -->
		 
		 <scroll-view class="fa1" scroll-x>
			  <view class="sson">
				  <view class="son1"></view>
				  <view class="son1"></view>
				  <view class="son1"></view>
				  <view class="son1"></view>
				  <view class="son1"></view>
				  <view class="son1"></view>
				  
			  </view>
		 </scroll-view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			}
		},
		methods: {
			
		}
	}
</script>

<style>
	
	
    .fa {
		width: 200px;
		height: 200px;
		background-color: pink;
	}
	
	.son {
		height: 50px;
		background-color: aquamarine;
		margin-bottom: 10px;
	}
	
	.fa1 {
		height: 50px;
		background-color: pink;
	}
	
	.sson {
		display: flex;
		width: 750px;
		height: 50px;
		background-color: orange;
	}
	
	.son1 {
		width: 150px;
		height: 50px;
		margin-right: 10px;
		background-color: red;
	}
</style>
