<template>
	<view>
		<!-- 
		   组件
		   1.view组件  基本的盒子组件
			 特点：
			   1.独占一行
			   2.默认宽度100%
			   
		   2.image组件  图像组件
		     属性：
			   1.src:引入图片的地址
			   2.mode:图片裁剪的方式
			   
		   3.input组件   输入框组件
		     属性：
			   1.value  默认值
			   2.password  是否为密码输入框
			   3.placeholder  占位符
		 -->
		 
		 <!-- 
		    css样式
			 1.类选择器
			   格式：
			     .类名 {
					 属性:属性值
				 }
				注意：
				  1.需要配合class属性来使用
				  2.一个元素可以存在多个类名
				  3.可以有多个相同类名出现
				  
				  
			 2.文字属性
			       1.color 颜色
				              英文单词
							  rgb
							  rgba
							  #16进制
							  
				   2.font-size  字体大小
				        默认16px
						最小12px
						
						
				   3.font-weight  字体粗细
				              bold  加粗
							  lighter  变细
							  
				   4.font-family  设置字体
				   
			 3.文本属性
			       1.text-align   文本水平对齐方式
				                  left  左对齐
								  center  居中
								  right  右对齐
								  
				   2.line-height   行高
				   
				     line-height = height  实现文本垂直居中
					 
					 
			4.盒子模型
			  标准的盒子模型： content(width+height)+padding(内边距)+border(边框)+margin(外边距)
			  
			  border-radius 设置圆角
			            px
						% ---> 50%  圆形
						
			  margin:auto  实现盒子水平居中
			  
			5.弹性盒子
			    特点：
				  1.会让子元素在主轴方向上一行
				  
				  
				容器属性：
				  1.flex-direction  设置主轴方向
				                    row  设置水平方向为主轴方向
									column  设置垂直方向为主轴方向
									
				  2.justify-content  设置主轴方向上的对齐方式
				                     flex-start  左对齐
									 center  居中
									 flex-end 右对齐
									 space-between   分散对齐
									 
				  3.align-items  设置交叉轴的对齐方式
				                flex-start 顶部对齐
								center  居中
								flex-end  底部对齐
								
			6.背景图片
			    1.background-image:url()  引入图片
				2.background-repeat    背景平铺
				                 repeat-x  在x轴上平铺
								 repeat-y  在y轴上平铺
								 no-repeat  不平铺
				3.background-size:width height   背景大小
				4.background-position:x y   背景位置
		  -->
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			}
		},
		methods: {
			
		}
	}
</script>

<style>

</style>
