<template>
	<view>
		<!-- 
		   position   定位
		              relative  相对定位
					  absolute  绝对定位
					  fixed     固定定位
					  
		
		   偏移量   left/right/top/bottom
		 -->
		 <!-- 
		    1.relative  相对定位
			  特点：
			   1.原来的位置依然存在
			   2.相对于自身进行偏移
		  -->
		  <!-- 
		    2.absolute  绝对定位
			  特点：
			   1.原来的位置不存在了
			   2.如果该元素的父级或者祖先元素存在定位，那么就相对于最近的父级或者祖先元素进行偏移
			     如果该元素的父级或者祖先元素没有定位，那么就相对于模拟器进行偏移
		   -->
		   <!-- 
			 3.子绝父相
			   如果某一个元素要使用定位，一般把该元素设置为绝对定位，然后将该元素的父级或者祖先元素设置为相对定位，
			   让该元素相对其父级或者祖先元素进行偏移
			-->
			<!-- 
			4.fixed  固定定位
			   特点：
			    1.原来的位置也不在了
				2.始终相对于模拟器进行偏移
			 -->
		 <view class="fa1"></view>
		 <view class="fa2">
			 <view class="son2">
				 <div class="sson"></div>
			 </view>
		 </view>
		 <view class="fa3"></view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			}
		},
		methods: {
			
		}
	}
</script>

<style>
      .fa1 {
		  position: fixed;
		  top: 0;
		  left: 0;
		  width: 100%;
		  height: 100px;
		  background-color: red;
	  }
	  
	  .fa2 {
		  width: 150px;
		  height: 150px;
		  background-color: green;
	  }
	  
	  .son2 {
		  width: 120px;
		  height: 120px;
		  background-color: pink;
	  }
	  
	  .sson {
		  width: 100px;
		  height: 100px;
		  background-color: black;
	  }
	  
	  .fa3 {
		  width: 200px;
		  height: 1000px;
		  background-color: blue
	  }
</style>
