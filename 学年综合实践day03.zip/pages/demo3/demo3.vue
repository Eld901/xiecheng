<template>
	<view>
		<!-- 
		   swiper组件  滑块视图 
		   注意：
		    1.swiper组件的子元素只能是swiper-item
		 -->
		 <swiper class="fa" indicator-dots indicator-active-color="#fff" autoplay interval="2000">
		 	<swiper-item>
				<image src="/static/demo3/1.webp" mode="" class="son"></image>
			</swiper-item>
			<swiper-item>
				<image src="/static/demo3/2.webp" mode="" class="son"></image>
			</swiper-item>
			<swiper-item>
				<image src="/static/demo3/3.webp" mode="" class="son"></image>
			</swiper-item>
		 </swiper>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			}
		},
		methods: {
			
		}
	}
</script>

<style>
   .fa {
	   height: 200px;
   }
   
   .son {
	   width: 100%;
	   height: 100%;
   }
</style>
