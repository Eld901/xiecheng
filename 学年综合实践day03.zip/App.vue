<script>
	export default {
		onLaunch: function() {
			console.log('App Launch')
		},
		onShow: function() {
			console.log('App Show')
		},
		onHide: function() {
			console.log('App Hide')
		}
	}
</script>

<style>
	/*每个页面公共css */
	/* 让滚动条消失 */
	::-webkit-scrollbar {
		width: 0;
		height: 0;
		/* transparent 透明 */
		background-color: transparent;
		/* display:none 控制元素消失 */
		display: none;
	}
</style>
