<template>
	<view>
		<view class="box">
			<image src="../../static/demo6/1.png" class="food"></image>
		</view>
		<scroll-view class="fa1" scroll-x>
			<view class="son">
				<view class="son1">本帮菜</view>
				<view class="son2">风味小吃</view>
				<view class="son3" @click="getS">老字号</view>
				<view class="son4">烧烤</view>
				<view class="son5">美食林</view>
				<view class="son6">海鲜</view>
				<view class="son7">居酒屋</view>
				<view class="son8">Bistro</view>
			</view>
		</scroll-view>
		<!-- 数据绑定，列表渲染 -->
	     <view v-bind:class="v" v-for="(item,index) in arr">店名{{item.name}},上榜理由{{item.why}},人均{{item.price}}</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
				v:"fa",
				arr:[
				 	{
				     	name:"上海王宝和大酒店上海餐厅",
		        		why:"主打蟹宴的百年老店，中式装修华丽气派",
			      		price:"￥394"
				 	},
				 	{
				     	name:"大壶春(四川中路店)",
				     	why:"坚持做全发面生煎，彰显传统老店品质",
				     	price:"￥28"
				 	},
				 	{
				     	name:"杏花楼(福州路总店)",
				 		why:"创于咸丰元年的老店，各式糕点水准上乘",
				 		price:"￥260"
				 	}
				 ]
			}
		},
		methods: {
			getS(){
				this.v="fa2"
			}
			
		}
	}
</script>

<style>
	.box{
		display: flex;
		margin-top:150px;
		justify-content: space-between;
		width: 359.200px;
		height: 32px;
		padding: 10px 4px 6px 12px;
	}
	.food{
		width: 107.325px;
		height: 23px;
		margin-right: 8px;
	}
	.fa1{
		height: 34px;
		background-color: #fff;
	}
	.son{
		display: flex;
		width: 1116px;
		height: 34px;
		background-color: #fff;
	}
	.son1{
		height: 34px;
		width: 70px;
		line-height: 34px;
		font-size: 14px;
		color: #673915;
		background: rgba(248, 213, 184, 0.3);
		border-radius: 18px;
		margin-left: 8px;
		text-align: center;
	}
	.son2{
		height: 34px;
		width: 70px;
		line-height: 34px;
		font-size: 14px;
		color: #673915;
		background: rgba(248, 213, 184, 0.3);
		border-radius: 18px;
		margin-left: 8px;
		text-align: center;
	}
	.son3{
		height: 34px;
		width: 70px;
		line-height: 34px;
		font-size: 14px;
		color: #673915;
		background: rgba(248, 213, 184, 0.3);
		border-radius: 18px;
		margin-left: 8px;
		text-align: center;
	}
	.son4{
		height: 34px;
		width: 70px;
		line-height: 34px;
		font-size: 14px;
		color: #673915;
		background: rgba(248, 213, 184, 0.3);
		border-radius: 18px;
		margin-left: 8px;
		text-align: center;
	}
	.son5{
		height: 34px;
		width: 70px;
		line-height: 34px;
		font-size: 14px;
		color: #673915;
		background: rgba(248, 213, 184, 0.3);
		border-radius: 18px;
		margin-left: 8px;
		text-align: center;
	}
	.son6{
		height: 34px;
		width: 70px;
		line-height: 34px;
		font-size: 14px;
		color: #673915;
		background: rgba(248, 213, 184, 0.3);
		border-radius: 18px;
		margin-left: 8px;
		text-align: center;
	}
	.son7{
		height: 34px;
		width: 70px;
		line-height: 34px;
		font-size: 14px;
		color: #673915;
		background: rgba(248, 213, 184, 0.3);
		border-radius: 18px;
		margin-left: 8px;
		text-align: center;
	}
	.son8{
		height: 34px;
		width: 70px;
		line-height: 34px;
		font-size: 14px;
		color: #673915;
		background: rgba(248, 213, 184, 0.3);
		border-radius: 18px;
		margin-left: 8px;
		text-align: center;
	}
	.fa{
		width: 10px;
		height: 100px;
		background-color: pink;
	}
	.fa2{
		width: 300px;
		height: 100px;
		background-color: aquamarine;
		border-radius: 20px;
		padding: 10px 12px;
		margin-left: 25px;
		margin-top: 10px;
	}
</style>
