<template>
	<view>
		<view class="header">
			<view class="hdtext">全球</view>
			<view class="hdipt">
				<image src="/static/shequ/search-icon.png" mode="" class="iptimg"></image>
				<input type="text" class="iptbox" placeholder="目的地/景点/话题...">
			</view>
		</view>
		
		<view class="main">
			<scroll-view class="main-left" scroll-y>
				<view class="ml-tag" @click="getId" data-id="fx">发现</view>
				<view class="ml-tag" @click="getId" data-id="tb">徒步</view>
				<view class="ml-tag" @click="getId" data-id="bs">避暑</view>
				<view class="ml-tag" @click="getId" data-id="kh">看海</view>
				<view class="ml-tag" @click="getId" data-id="wl">玩乐</view>
				<view class="ml-tag" @click="getId" data-id="jd">酒店</view>
				<view class="ml-tag" @click="getId" data-id="ms">美食</view>
		    </scroll-view>
			<scroll-view class="main-right" scroll-y :scroll-into-view="id" scroll-with-animation>
					<view class="mr-tag" id="fx">
					 <view class="fx1">
					 	<image src="../../static/shequ/fx.1.jpg" class="fx1"></image>
					 	<view class="fxt1"><发现>森林卧室做秋千，是要飞出天际的感觉没错啦</view>
					 	<view class="fx1t">
					 		<image src="../../static/shequ/fx.1t.jpg" mode="" class="fx1timg"></image>
					 		<view>探店达人</view>
					 		<image src="../../static/good.png" mode="" class="fx1zimg"></image>
					 	</view>
					 	<view class="gd" @click="gotopage">查看更多---></view>
					 </view>
					 </view>
					<view class="mr-tag" id="tb">
						<view class="fx1">
							<image src="../../static/shequ/tb.2.jpg" class="fx1"></image>
							<view class="fxt1"><徒步>徒步探洞，温泉溯溪，正是户外好春光！</view>
							<view class="fx1t">
								<image src="../../static/shequ/tb.1t.jpg" mode="" class="fx1timg"></image>
								<view>一个括弧</view>
								<image src="../../static/good.png" mode="" class="fx1zimg"></image>
							</view>
							<view class="gd">查看更多---></view>
						</view>
					</view>
					<view class="mr-tag" id="bs">
						<view class="fx1">
							<image src="../../static/shequ/bs1.jpg" class="fx1"></image>
							<view class="fxt1"><避暑>上犹燕子岩 消暑好去处</view>
							<view class="fx1t">
								<image src="../../static/shequ/bs1t.jpg" mode="" class="fx1timg"></image>
								<view>独行旅者</view>
								<image src="../../static/good.png" mode="" class="fx1zimg"></image>
							</view>
							<view class="gd">查看更多---></view>
						</view>
					</view>
					<view class="mr-tag" id="kh">
						<view class="fx1">
							<image src="../../static/shequ/kh1.jpg" class="fx1"></image>
							<view class="fxt1"><看海>去三亚我为什么选择物美价廉的酒店式公寓</view>
							<view class="fx1t">
								<image src="../../static/shequ/kh1t.jpg" mode="" class="fx1timg"></image>
								<view>会走路的红袋鼠</view>
								<image src="../../static/good.png" mode="" class="fx1zimg"></image>
							</view>
							<view class="gd">查看更多---></view>
						</view>
					</view>
					<view class="mr-tag" id="wl">
						<view class="fx1">
							<image src="../../static/shequ/wl1.jpg" class="fx1"></image>
							<view class="fxt1"><玩乐>中卫乡村旅游攻略（一）</view>
							<view class="fx1t">
								<image src="../../static/shequ/wl1t.jpg" mode="" class="fx1timg"></image>
								<view>名图Dream+</view>
								<image src="../../static/good.png" mode="" class="fx1zimg"></image>
							</view>
							<view class="gd">查看更多---></view>
						</view>
					</view>
					<view class="mr-tag" id="jd">
						<view class="fx1">
							<image src="../../static/shequ/jd1.jpg" class="fx1"></image>
							<view class="fxt1"><酒店>九华山巷里兰庭，不容错过的闹中取静</view>
							<view class="fx1t">
								<image src="../../static/shequ/jd1t.jpg" mode="" class="fx1timg"></image>
								<view>游游的完美旅程</view>
								<image src="../../static/good.png" mode="" class="fx1zimg"></image>
							</view>
							<view class="gd">查看更多---></view>
						</view>
					</view>
					<view class="mr-tag" id="ms">
						<view class="fx1">
							<image src="../../static/shequ/ms1.jpg" class="fx1"></image>
							<view class="fxt1"><美食>厦门旅行|美味之旅川九</view>
							<view class="fx1t">
								<image src="../../static/shequ/ms1t.jpg" mode="" class="fx1timg"></image>
								<view>Oneone旅行</view>
								<image src="../../static/good.png" mode="" class="fx1zimg"></image>
							</view>
							<view class="gd">查看更多---></view>
						</view>
					</view>
				</scroll-view>
			</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				id:"",
				
			}
		},
		methods: {
			getId(e){
				console.log(e.target.dataset.id);
				this.id=e.target.dataset.id
			},
			 gotopage() {
			                this.$router.push({
			                    path:'/pages/fx/fx',
			                })
			            }
		}
	}
</script>

<style>
	.header {
		display: flex;
		height: 54px;
	}
	
	.hdtext {
		width: 90px;
		height: 54px;
		color: #666666;
		font-size: 18px;
		text-align: center;
		line-height: 54px;
	}
	
	.hdipt {
		position: relative;
	}
	
	.iptimg {
		position: absolute;
		top: 17px;
		left: 20px;
		width: 20px;
		height: 20px;
	}
	
	.iptbox {
		width: 228px;
		height: 32px;
		padding-left: 33px;
		margin: 11px 12px;
		background-color: #F7F7F7;
		border-radius: 20px;
	}
	.main{
		display: flex;
	}
	.main-left {
		width: 90px;
		height: 563px;
	}
	
	.main-right {
		width: 100%;
		padding: 0 15px;
		height: 563px;
	}
	.ml-tag {
		width: 40px;
		height: 50px;
		padding: 0 15px;
		font-size: 14px;
		color: #222;
		text-align: center;
		line-height: 50px;
		
	}
	.mr-tag {
		width: 100%;
		height: 300px;
		background-color: antiquewhite;
		margin-bottom: 20px;
	}
	.fx1{
		width: 100%;
		height: 200px;
		border-radius: 10%;
	}
	.fxt1{
		width: 95%;
		height: 52px;
	}
	.fx1t{
		display: flex;
	}
	.fx1timg{
		height: 20px;
		width: 20px;
		border-radius: 50%;
	}
	.fx1zimg{
		height: 20px;
		width: 20px;
		margin-left: 80px;
	}
	.gd{
		color: lightblue;
		margin-left: 150px;
	}
	
	
</style>
