<template>
	<view>
		<view class="x1">
			<image src="../../static/shequ/fx2.jpg" mode="" class="mg1"></image>
			<view class="t1">端午去哪玩？ 山东威海</view>
			<view>游玩时间3-4天 推荐路线：摩天岭-金石湾-鸡鸣岛-那香海</view>
			<view class="yonghu">
			<image src="../../static/shequ/fx2t.jpg" mode="" class="mg2"></image>	
			<view>旅行家老白</view>
			<image src="../../static/喜欢.png" mode="" class="mg2"></image>
			<image src="../../static/消息-置灰.png" mode="" class="mg2"></image>
			</view>
		</view>
		<view class="x1">
			<image src="../../static/shequ/fx.1.jpg" mode="" class="mg1"></image>
			<view class="t1">森林卧室做秋千，体验飞一样的感觉</view>
			<view>游玩时间3-4天 推荐路线：摩天岭-金石湾-鸡鸣岛-那香海</view>
			<view class="yonghu">
			<image src="../../static/shequ/fx.1t.jpg" mode="" class="mg2"></image>	
			<view>探店达人</view>
			<image src="../../static/喜欢.png" mode="" class="mg2"></image>
			<image src="../../static/消息-置灰.png" mode="" class="mg2"></image>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			}
		},
		methods: {
			
		}
	}
</script>

<style>
	.x1{
		height: 400px;
		width: 100%;
		background-color: lavenderblush;
		margin-top: 10px;
	}
	.mg1{
		height: 250px;
		width: 100%;
		border-radius: 10%;
	}
	.t1{
		font-weight: bold;
	}
	.yonghu{
		display: flex;
		height: 50px;
		width: 100%;
		margin-top: 50px;
	}
	.mg2{
		height: 30px;
		width: 30px;
		border-radius: 50%;
	}

</style>
