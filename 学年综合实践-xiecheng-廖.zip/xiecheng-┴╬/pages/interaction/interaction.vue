<template>
	<view>
		<view class="container1">
				<navigator url="../message/message" open-type="switchTab">
				<image src="/static/message/返回.png" mode="" class="return"></image>
				</navigator>
				<view class="title">互动消息</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			}
		},
		methods: {
			
		}
	}
</script>

<style>
	.container1 {
		width: 100%;
		height: 44px;
		
		display: flex; //放在水平主轴上
		align-items: center; //垂直居中
		justify-content: center;
		position: fixed;
	}
	
	.return {
		width: 22px;
		height: 22px;
		
		position: absolute;//控制return返回键相对于模拟器顶部和左部的位置
		top:13px;
		left:11px;  
	}
	.title {
		font-size: 17px;
	}

</style>
