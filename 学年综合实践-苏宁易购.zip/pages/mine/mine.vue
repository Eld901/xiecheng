<template>
	<view>
		<view class="logobox">
			<image :src="lgimg" mode="" class="lgimg"></image>
			<view>{{lgname}}</view>
		</view>

		<view class="btn" @click="getLogo">
			登录
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				lgimg: "/static/mine/1.png",
				lgname: "欢迎使用苏宁易购"
			}
		},
		methods: {
			getLogo() {
				// 缓存外界的  this   方便后面使用
				let that = this;

				// 1.显示提示框
				// uni.showToast({
				// 	title:"登录成功",
				// 	icon:"fail",
				// 	duration:5000
				// })

				// 2.显示正在加载提示框
				// uni.showLoading({
				// 	title:"正在加载..."
				// })

				// 定时器 setTimeout(function() {}, 10);  第一个参数代表执行函数  第二个参数代表多少毫秒后执行前面的函数
				// setTimeout(function(){
				// 	// 关闭正在加载提示框
				// 	uni.hideLoading()
				// 	// 关闭正在加载提示框后 设置头像和昵称
				// 	that.lgimg = "/static/mine/tx.webp";
				// 	that.lgname = "小红";
				// },2000)
				
			



				// 3.模态框弹窗
				uni.showModal({
					title: "登录提示",
					content: "是否登录",
					success: function(res) {
						if (res.confirm) {
							uni.showLoading({
								title: "加载中..."
							})

							setTimeout(function() {
								uni.hideLoading()
								that.lgimg = "/static/mine/tx.webp";
								that.lgname = "小红";
								
								uni.showToast({
									title:"登录成功"
								})
								
								// 需要存入一个缓存 表示登录 
								uni.setStorage({
									key:"islogin",
									data:"001",
									success:function(){
										console.log("缓存成功");
									}
								})
							}, 2000)
						} else if (res.cancel) {
							uni.showToast({
								title:"登录失败",
								icon:"error"
							})
						}

					}
				})
			}
		},
		// 生命周期
		// 页面加载的时候触发  只触发一次
		onLoad() {
			let that = this
			
			// 在页面加载的时候获取登录缓存
			uni.getStorage({
				// 通过key值获取缓存
				key:"islogin",
				success(res) {
					// res.data里面 就是 islogin对应的Key值、
					// 判断是否存在缓存
					if(res.data) {
						// 如果存在   直接设置头像和昵称
						that.lgimg = "/static/mine/tx.webp";
						that.lgname = "xioo"
					}
				}
			})
		},
		// 页面显示的时候触发
		onShow() {
			console.log("触发了 onshow");
		},
		// 页面加载完毕触发  只触发一次
		onReady() {
			console.log("触发了 onready");
		},
		// 页面隐藏 触发
		onHide() {
			console.log("触发了 onhide");
		}
	}
</script>

<style>
	.logobox {
		display: flex;
		justify-content: center;
		align-items: center;
		margin-top: 200px;
	}

	.lgimg {
		width: 45px;
		height: 45px;
		border-radius: 50%;
		margin-right: 15px;
	}

	.btn {
		width: 250px;
		height: 40px;
		text-align: center;
		line-height: 40px;
		background-color: #FFCC00;
		font-size: 18px;
		font-weight: bold;
		border-radius: 10px;
		margin: 50px auto;
	}
</style>