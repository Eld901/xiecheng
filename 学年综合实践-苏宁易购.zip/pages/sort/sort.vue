<template>
	<view>
		<view class="header">
			<view class="hdtext">商品分类</view>
			<view class="hdipt">
				<image src="/static/sort/search-icon.png" mode="" class="iptimg"></image>
				<input type="text" class="iptbox" placeholder="请输入商品或店铺">
			</view>
		</view>
		<view class="main">
			<scroll-view class="main-left" scroll-y>
				<!-- 自定义属性  data-name   -->
				<view class="ml-tag tag1" @click="getId" data-id="hot">热门推荐</view>
				<view class="ml-tag" @click="getId" data-id="sj">手机</view>
				<view class="ml-tag" @click="getId" data-id="kt">空调</view>
				<view class="ml-tag" @click="getId" data-id="bx">冰箱</view>
				<view class="ml-tag" @click="getId" data-id="ls">零食</view>
				<view class="ml-tag">空调</view>
				<view class="ml-tag">冰箱</view>
				<view class="ml-tag">手机</view>
				<view class="ml-tag">空调</view>
				<view class="ml-tag">冰箱</view>
				<view class="ml-tag">手机</view>
				<view class="ml-tag">空调</view>
				<view class="ml-tag">冰箱</view>
				<view class="ml-tag">手机</view>
				<view class="ml-tag">空调</view>
				<view class="ml-tag">冰箱</view>
			</scroll-view>
			<scroll-view class="main-right" scroll-y :scroll-into-view="id" scroll-with-animation>
				<view class="mr-tag" id="hot">热门推荐</view>
				<view class="mr-tag" id="sj">手机</view>
				<view class="mr-tag" id="kt">空调</view>
				<view class="mr-tag" id="bx">冰箱</view>
				<view class="mr-tag" id="ls">零食</view>
			</scroll-view>
			
			<view class="fa">
				<view class="son1"></view>
				<view class="son2"></view>
				<view class="son3"></view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
                id:""
			}
		},
		methods: {
			// 事件对象   e
			getId(e){
				console.log(e.target.dataset.id);
				
				this.id = e.target.dataset.id
			}
			
			
		}
	}
</script>

<style>
	.header {
		display: flex;
		height: 54px;
	}

	.hdtext {
		width: 90px;
		height: 54px;
		color: #333;
		font-size: 18px;
		text-align: center;
		line-height: 54px;
	}

	.hdipt {
		position: relative;
	}

	.iptimg {
		position: absolute;
		top: 17px;
		left: 20px;
		width: 20px;
		height: 20px;
	}

	.iptbox {
		width: 228px;
		height: 32px;
		padding-left: 33px;
		margin: 11px 12px;
		background-color: #F7F7F7;
		border-radius: 20px;
	}

	.main {
		display: flex;
	}

	.main-left {
		width: 90px;
		height: 563px;
	}

	.main-right {
		width: 255px;
		padding: 0 15px;
		height: 563px;
	}

	.tag1 {
		font-weight: bold;
	}

	.ml-tag {
		width: 65px;
		height: 50px;
		padding: 0 12.5px;
		font-size: 14px;
		color: #222;
		text-align: center;
		line-height: 50px;
	}

	.mr-tag {
		width: 100%;
		height: 300px;
		background-color: pink;
		margin-bottom: 10px;
	}
</style>