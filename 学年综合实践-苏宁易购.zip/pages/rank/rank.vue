<template>
	<view>

		<scroll-view scroll-y="true" class="chatbox" :scroll-top="maxlength" scroll-with-animation>
			<view v-for="(item,index) in chatbox">
				<view class="mybox" v-if="item.ismine">
					<view class="mytext">{{item.msg}}</view>
					<image src="/static/rank/myhd.webp" mode="" class="myhd"></image>
				</view>
				<view class="youbox" v-if="item.isyou">
					<image src="/static/rank/youhd.webp" mode="" class="youhd"></image>
					<view class="youtext">{{item.msg}}</view>
				</view>
			</view>
		</scroll-view>





		<view class="msgbox">
			<input type="text" class="ipt" v-model="mytext">
			<view class="btn" @click="sendMsg">发送</view>
		</view>

	</view>
</template>

<script>
	export default {
		data() {
			return {
				mytext: "",
				msgmine: "",
				chatbox: [],
				maxlength:''
			}
		},
		methods: {
			sendMsg() {
				// 首先声明变量缓存用户输入的值
				let mymsg = this.mytext;
				// 把用户输入的值重新设置为空  清除输入框里面的值
				this.mytext = "";

				// 将获取到  用户输入的值  以对象的形式 追加到 chatbox数组
				let my = {
					ismine: 1,
					msg: mymsg
				}
				this.chatbox.push(my);
				this.maxlength = this.chatbox.length+10000

				// 将我们的文本发送给ai接口
				let that = this
				uni.request({
					url: "/api",
					method: "GET",
					data: {
						key: "free",
						appid: 0,
						msg: mymsg
					},
					success(res) {
						console.log(res.data.content);
						let you = {
							isyou: 1,
							msg: res.data.content
						}

						that.chatbox.push(you)
						that.maxlength = this.chatbox.length+10000
					}
				})


			}
		}
	}
</script>

<style>
	.chatbox {
		/* width: 100%; */
		height: 557px;
		padding: 0 10px;
		box-sizing: border-box;
		background-color: aquamarine;
	}


	.mybox {
		display: flex;
		justify-content: flex-end;
		margin-bottom: 10px;
	}

	.mytext {
		background-color: #fff;
		padding: 8px;
		border-radius: 8px;
		max-width: 256px;
	}

	.myhd {
		width: 40px;
		height: 40px;
		border-radius: 50%;
		background-color: pink;
		margin-left: 10px;
	}

	.youbox {
		display: flex;
		justify-content: flex-start;
		margin-bottom: 10px;
	}

	.youtext {
		background-color: #fff;
		padding: 8px;
		border-radius: 8px;
		max-width: 256px;
	}

	.youhd {
		width: 40px;
		height: 40px;
		border-radius: 50%;
		background-color: pink;
		margin-right: 10px;
	}

	.msgbox {
		position: fixed;
		bottom: 50px;
		display: flex;
		align-items: center;
		justify-content: center;
		height: 60px;
		width: 100%;
		background-color: pink;
	}

	.ipt {
		height: 30px;
		width: 250px;
		background-color: #fff;
		border-radius: 10px;
		padding-left: 10px;
	}

	.btn {
		padding: 6px 10px;
		background-color: skyblue;
		border-radius: 10px;
		margin-left: 5px;
		font-size: 14px;

	}
</style>