<template>
	<view>
		<!-- 头部区域 -->
		<view class="header">
			<view class="container">
				<!-- 导航条区域 -->
				<view class="nav">
					<navigator url="../sort/sort" open-type="switchTab">
						<image src="/static/index/1.png" mode="" class="navimg1"></image>
					</navigator>

					<image src="/static/index/2.gif" mode="" class="navimg2"></image>
					<navigator url="../mine/mine" open-type="switchTab">
						<image src="/static/index/2.png" mode="" class="navimg3"></image>
					</navigator>

				</view>
				<!-- 搜索区域 -->
				<view class="ssbox">
					<view class="ss">
						<image src="/static/index/ss.png" mode="" class="ssimg"></image>
						<input type="text" class="iptbox" placeholder="商品/店铺">
					</view>
				</view>

			</view>
		</view>

		<!-- 分类区域 -->
		<view class="sortbox">
			<view class="sort">
				<view class="typebox">
					<image src="/static/index/4.png" mode="" class="tpimg"></image>
					<view class="tptext">苏宁家电</view>
				</view>
				<view class="typebox">
					<image src="/static/index/4.png" mode="" class="tpimg"></image>
					<view class="tptext">苏宁家电</view>
				</view>
				<view class="typebox">
					<image src="/static/index/4.png" mode="" class="tpimg"></image>
					<view class="tptext">苏宁家电</view>
				</view>
				<view class="typebox">
					<image src="/static/index/4.png" mode="" class="tpimg"></image>
					<view class="tptext">苏宁家电</view>
				</view>
				<view class="typebox">
					<image src="/static/index/4.png" mode="" class="tpimg"></image>
					<view class="tptext">苏宁家电</view>
				</view>
			</view>
			<view class="sort">
				<view class="typebox">
					<image src="/static/index/4.png" mode="" class="tpimg"></image>
					<view class="tptext">苏宁家电</view>
				</view>
				<view class="typebox">
					<image src="/static/index/4.png" mode="" class="tpimg"></image>
					<view class="tptext">苏宁家电</view>
				</view>
				<view class="typebox">
					<image src="/static/index/4.png" mode="" class="tpimg"></image>
					<view class="tptext">苏宁家电</view>
				</view>
				<view class="typebox">
					<image src="/static/index/4.png" mode="" class="tpimg"></image>
					<view class="tptext">苏宁家电</view>
				</view>
				<view class="typebox">
					<image src="/static/index/4.png" mode="" class="tpimg"></image>
					<view class="tptext">苏宁家电</view>
				</view>
			</view>
		</view>

		<!-- 商品区域 -->

		<view class="bigbox">
			<view class="container">
				<view class="goodsbox">
					<view class="gd-left">
						<view class="goods" v-for="(item,index) in goodsarr">
							<image :src="item.img" mode="" class="gdsimg"></image>
							<view class="gdstext">{{item.text}}</view>
							<view class="gdstag">
								<image src="/static/index/7.png" mode="" class="hwzy" v-if="item.ishwzy"></image>
								<image src="/static/index/6.png" mode="" class="zy" v-if="item.iszy"></image>
							</view>
							<view class="gdsprice">
								<view class="price">
									￥{{item.price}}
								</view>
								<view class="mark">
									{{item.mark}}+评价
								</view>
							</view>
						</view>
					</view>
					<view class="gd-right"></view>
				</view>
			</view>
		</view>


		<!-- gotoLogin区域 -->

		<view class="gotoLogin" v-if="isout">
			<navigator url="../mine/mine" open-type="switchTab" style="width: 100%;height: 100%;"></navigator>
		</view>

		<view style="height: 1000px;">

		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				isout:1,
				goodsarr: [
					{
						img: "/static/index/1.webp",
						text: "五个农民琥珀核桃仁500g罐装",
						price: '44.9',
						mark: '2800',
						iszy:1
					},
					{
						img: "/static/index/2.webp",
						text: "XQG70-10121T",
						price: '110.8',
						mark: '1000',
						ishwzy:1
					},
					{
						img: "/static/index/3.webp",
						text: "【国内专柜版 正品保证】雅诗兰黛DW持妆粉",
						price: '239.5',
						mark: '500',
						iszy:1
					},
					{
						img: "/static/index/4.webp",
						text: "清扬(CLEAR)植觉男士净醒去屑 洗发露 380ml",
						price: '299.9',
						mark: '400',
						iszy:1
					},{
						img: "/static/index/4.webp",
						text: "9999",
						price: '888',
						mark: '1'
					}
				]
			}
		},
		methods: {

		},
		onLoad() {
			console.log("我是onload函数");
			
		},
		onShow() {
			console.log("我是index页面的onshow");
			let that = this;
			// 获取缓存
			uni.getStorage({
				key:"islogin",
				success(res) {
					if(res.data) {
						that.isout = 0
					}
				},
				fail() {
					that.isout = 1
				}
			})
			
		}
	}
</script>

<style>
	.header {
		background-image: url(/static/index/2.jpg);
		background-repeat: no-repeat;
		background-size: cover;
	}

	.container {
		width: 93%;
		margin: auto;
	}

	.nav {
		display: flex;
		justify-content: space-between;
		align-items: center;
		height: 44px;

	}

	.navimg1 {
		width: 18px;
		height: 30px;
	}

	.navimg2 {
		width: 195px;
		height: 38px;
	}

	.navimg3 {
		width: 18px;
		height: 30px;
	}

	.ssbox {
		display: flex;
		align-items: center;
		height: 46px;

	}

	.ss {
		position: relative;
		height: 32px;
		width: 100%;
		background-color: #fff;
		border-radius: 20px;
	}

	.ssimg {
		position: absolute;
		top: 7px;
		left: 10px;
		width: 18px;
		height: 18px;
	}

	.iptbox {
		height: 32px;
		padding-left: 32px;
		padding-right: 10px;
	}



	.sortbox {
		height: 160px;
		background-image: url(/static/index/1.jpg);
		background-repeat: no-repeat;
		background-size: 100% 100%;
	}

	.sort {
		display: flex;
	}

	.typebox {
		display: flex;
		flex-direction: column;
		justify-content: flex-end;
		align-items: center;
		width: 75px;
		height: 71px;
	}

	.tpimg {
		width: 42px;
		height: 42px;
	}

	.tptext {
		color: #666;
		font-size: 12px;
		margin-top: 2.5px;
	}

	.gotoLogin {
		position: fixed;
		bottom: 50px;
		height: 45px;
		width: 100%;
		background-image: url(/static/index/5.png);
		background-repeat: no-repeat;
		background-size: 100% 100%;
	}

	.goodsbox {
		display: flex;
		justify-content: space-between;
	}

	.gd-left {
		width: 171px;

	}

	.gd-right {
		width: 171px;

	}

	.goods {
		background-color: pink;
		border-radius: 10px;
		padding-bottom: 5px;
		overflow: hidden;
		margin-bottom: 10px;

	}

	.gdsimg {
		width: 171px;
		height: 171px;
	}

	.gdstext {
		width: 159px;
		height: 33.5px;
		margin: 9px auto 0px;
		font-size: 13px;
		color: #333;
		font-weight: bold;
	}

	.gdstag {
		display: flex;
		height: 12px;
		margin: 5.5px 6px 12px;
	}
	
	.hwzy {
		width: 64px;
		height: 12px;
	}

	.zy {
		width: 24px;
		height: 12px;
	}

	.gdsprice {
		display: flex;
		align-items: center;
	}

	.price {
		font-size: 17px;
		color: red;
		margin-right: 5px;
	}

	.mark {
		font-size: 12px;
		color: #999;
	}
</style>