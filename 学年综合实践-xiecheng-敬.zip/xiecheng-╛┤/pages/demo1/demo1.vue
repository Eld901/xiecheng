<template>
	<view>
		<!-- 搜索区域 -->
		<view class="search-index">
			<view class="ssbox" >
				<image src="../../static/demo1/search-icon.png" mode="" class="ssimg"></image>
				<input type="text" class="sstext" placeholder="搜索:目的地/酒店/景点/航班号">
			</view>
		</view>
		<!-- 分类区域 -->
		<view class="nav">
			<view class="nav-warp">
			    <view class="A1">
				    <image src="../../static/demo1/hotel.png" class="a1"></image>
				    <view class="at">酒店</view>
			    </view>
				<view class="A2">
				    <image src="../../static/demo1/flight.png" class="a1"></image>
				    <view class="at">机票</view>
			    </view>
			    <view class="A3">
				    <image src="../../static/demo1/train_ticket.png" class="a1"></image>
				    <view class="at">火车票</view>
			    </view>
			    <view class="A4">
			    	<image src="../../static/demo1/vacation.png" class="a1"></image>
			    	<view class="at">旅游</view>
		    	</view>
			    <view class="A5">
			    	<image src="../../static/demo1/gs.png" class="a1"></image>
			    	<view class="at">攻略/景点</view>
			    </view>
		    </view>
	        <view class="nav-warp1">
		    	<view class="B1">
			    	<image src="../../static/demo1/hotel_inn.png" class="a1"></image>
			    	<view class="bt">民宿/客栈</view>
			    </view>
		    	<view class="B2">
	    			<image src="../../static/demo1/flight_package.png" class="a1"></image>
	    			<view class="bt">机+酒</view>
	    		</view>
		        <view class="B3">
	     			<image src="../../static/demo1/bus_ticket.png" class="a1"></image>
    				<view class="bt">汽车/船票</view>
	    		</view>
    			<view class="B4">
   					<image src="../../static/demo1/ticket.png" class="a1"></image>
		    		<view class="bt">门票/活动</view>
    			</view>
		    	<view class="B5">
		    		<image src="../../static/demo1/food.png" class="a1"></image>
	    			<view class="bt">美食</view>
	      		</view>
        	</view>
    		<view class="nav-warp2">
		    	<view class="B1">
			    	<image src="../../static/demo1/hotel_sale.png" class="a1"></image>
		    		<view class="bt">特价/爆款</view>
		    	</view>
	    		<view class="B2">
		    		<image src="../../static/demo1/airport_transfer.png" class="a1"></image>
	    			<view class="bt">接送机/包车</view>
		    	</view>
		    	<view class="B3">
	     			<image src="../../static/demo1/car.png" class="a1"></image>
	    			<view class="bt">租车</view>
    			</view>
    			<view class="B4">
    				<image src="../../static/demo1/weekend.png" class="a1"></image>
    				<view class="bt">周边游</view>
    			</view>
     			<view class="B5">
    				<image src="../../static/demo1/shop.png" class="a1"></image>
    				<view class="bt">购物/免税</view>
    			</view>
		    </view>
		</view>
		<!-- 推荐区域 -->
		<view class="sub-banner">
			<view class="banner">
				<view class="block-header">
					<image src="../../static/demo1/1.png" class="title"></image>
					<view class="slogan-hotsale">特价好货直播中</view>
				</view>
				<swiper class="container" indicator-dots indicator-active-color="#fff" autoplay interval="2000">
					<swiper-item>
						<view class="block-image1">
							<image src="../../static/demo1/room1.jpg" class="image1"></image>
							<view class="tag1">酒店套餐</view>
							<view class="tag2">欢橙酒店(资阳北站店)1晚</view>
						</view>
						<view class="block-footer1">
							<view class="price">￥99</view>
						</view>
					</swiper-item>
					<swiper-item>
						<view class="block-image1">
							<image src="../../static/demo1/room2.jpg" class="image1"></image>
							<view class="tag1">酒店套餐</view>
							<view class="tag2">外滩荷韵主题酒店(鼎盛国际万达广场店)1晚</view>
						</view>
						<view class="block-footer1">
							<view class="price">￥198</view>
						</view>
					</swiper-item>
					<swiper-item>
						<view class="block-image1">
							<image src="../../static/demo1/room3.jpg" class="image1"></image>
							<view class="tag1">酒店套餐</view>
							<view class="tag2">天府国际大酒店3晚</view>
						</view>
						<view class="block-footer1">
							<view class="price">￥618</view>
						</view>
					</swiper-item>
				</swiper>
			</view>
			
			<view class="banner">
				<view class="block-header">
					<image src="../../static/demo1/2.png" class="title"></image>
					<view class="slogan-rank">权威排行榜</view>
				</view>
				<view class="rank-wrapper">
					<view class="rank-item">
						<view class="block-image">
							<image src="../../static/demo1/room4.jpg" class="img"></image>
					     	<view class="tag">上海</view>
				     	</view>
			     		<view class="block-footer">
				    		<view class="rank-title">上海奢华酒...</view>
			    		</view>
					</view>
					<view class="rank-item" @click="getFood">    <!-- 事件绑定 -->
						<navigator url="../demo6/demo6" >    <!-- url链接地址后面不能有.vue后缀 -->
							<view class="block-image">
					    		<image src="../../static/demo1/room5.jpg" class="img"></image>
					    		<view class="tag">上海</view>
				    		</view>
				     		<view class="block-footer">
					    		<view class="rank-title">上海特色老...</view>
					    	</view>
						</navigator>
						
					</view>
				</view>
			</view>
		</view>
		<!-- 广告区域 -->
		<view class="ad-banner-wrap">
			<view class="img_wrap">
				<image src="../../static/demo1/提示.jpg" class="img1"></image>
			</view>
		</view>
		<!-- 选项区域 -->
		<view class="toolbox">
			<view class="tool-gruop">
				<view class="tool-link">
					<image src="../../static/demo1/3.1电话.png" class="img2"></image>
					<view class="t">电话预订</view>
				</view>
				<view class="tool-link">
					<image src="../../static/demo1/下载.png" class="img2"></image>
					<view class="t">下载携程</view>
				</view>
			</view>
			<image src="../../static/demo1/signin-d.png" class="sign"></image>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			}
		},
		methods: {
			getFood(){
				//显示正在加载提示框
				uni.showLoading({
					title:"即将呈现"
				})
				//定时器
				setTimeout(function(){
					//关闭正在加载提示框
					uni.hideLoading()
					//显示消息提示框
					uni.showToast({
			 		title:"加载成功",
					icon:"success",
			 	    })
				},1000)
				
			}
		}
	}
</script>

<style>
	.search-index{
		display: flex;
		width: 351.200px;
		height: 32px;
		background-color: #fff;
		padding: 12px 12px 6px 12px;
		
	}
	.ssbox{
		display: flex;
		height: 28.800px;
		flex: 1;
		border-radius: 32px;
		border: 1.8px solid #0086f6;
		color: #f4f4f4;
		font-size: .94rem;
		justify-content: flex-start;
		align-items: center;
	}
	.ssimg{
		height: 20px;
		width: 20px;
		color: #666;
		font-size: 20px;
		margin-left: 12px;
	}
	.sstext{
		width: 202.512px;
		height: 21px;
		margin-left: 6px;
		color: #666;
		font-size: 15px;
	}
	
	.nav{
		height: 184px;
		width: 375.200px;
		background-color: #fff;
	}
	.nav-warp{
		width: 351.200px;
		height: 176px;
		display: flex;
		flex-direction: row;
		margin: 6px 12px 2px 12px;
		border-radius: 10px;
		overflow: hidden;  /* 隐藏角 */
	}
	.nav-warp1{
		position: absolute;  /* 绝对定位 */
		top: 109px;          /* 偏移量109px */    
		width: 351.200px;
		height: 176px;
		display: flex;
		flex-direction: row;
		margin: 6px 12px 2px 12px;
	}
	.nav-warp2{
		position: absolute;  /* 绝对定位 */
		top: 167.5px;          /* 偏移量167.5px */    
		width: 351.200px;
		height: 176px;
		display: flex;
		flex-direction: row;
		margin: 6px 12px 2px 12px;
	}
	.A1{
		display: flex;
		width: 69.438px;
		height: 58px;
		flex-direction: column;
		align-items: center;
		justify-content: center;
		background-color: tomato;
	}
	.A2{
		display: flex;
		width: 69.438px;
		height: 58px;
		flex-direction: column;
		align-items: center;
		justify-content: center;
		background-color: deepskyblue;
	}
	.A3{
		display: flex;
		width: 69.438px;
		height: 58px;
		flex-direction: column;
		align-items: center;
		justify-content: center;
		background-color: dodgerblue;
	}
	.A4{
		display: flex;
		width: 69.438px;
		height: 58px;
		flex-direction: column;
		align-items: center;
		justify-content: center;
		background-color: mediumseagreen;
	}
	.A5{
		display: flex;
		width: 69.438px;
		height: 58px;
		flex-direction: column;
		align-items: center;
		justify-content: center;
		background-color: orange;
	}
	.B1{
		display: flex;
		width: 69.438px;
		height: 58px;
		flex-direction: column;
		align-items: center;
		justify-content: center;
		background-color: mistyrose;
	}
	.B2{
		display: flex;
		width: 69.438px;
		height: 58px;
		flex-direction: column;
		align-items: center;
		justify-content: center;
		background-color: rgb(203, 247, 255);
	}
	.B3{
		display: flex;
		width: 69.438px;
		height: 58px;
		flex-direction: column;
		align-items: center;
		justify-content: center;
		background-color: rgb(208, 227, 255);
	}
	.B4{
		display: flex;
		width: 69.438px;
		height: 58px;
		flex-direction: column;
		align-items: center;
		justify-content: center;
		background-color: rgb(171, 255, 195);
	}
	.B5{
		display: flex;
		width: 69.438px;
		height: 58px;
		flex-direction: column;
		align-items: center;
		justify-content: center;
		background-color: moccasin;
	}
	.a1{
		width: 28px;
		height: 28px;
		margin-bottom: 4px;
		background-repeat: no-repeat;
	}
	.at{
		width: 100%;
		height: 15px;
		color: #fff;
		line-height: 15px;
		font-family: "PingFangSC-Medium";
		font-size: 12px;
		text-align: center;
	}
	.bt{
		width: 100%;
		height: 15px;
		color: #000;
		line-height: 15px;
		font-family: "PingFangSC-Medium";
		font-size: 12px;
		text-align: center;
	}
	
	.sub-banner{
		display: flex;
		width: 359.200px;
		height: 148px;
		background-color: #fff;
		padding: 0 12px;
		margin-left: -8px;
		margin-bottom: 10px;
	}
	.banner{
		width: 155.600px;
		height: 132px;
		padding: 8px;
		margin-left: 8px;
		border-radius: 8px;
		background-color: #f4f4f4;
	}
	.block-header{
		display: flex;
		height: 20px;
		margin-bottom: 6px;
		justify-content: space-between;   /* 两端对齐 */
		align-items: center;
	}
	.title{
		width: 73px;
		height: 20px;
	}
	.slogan-hotsale{
		width: 92px;
		height: 16px;
		border-radius: 2px;
		font-size: 12px;
		background: #ffebe3;
		color:#ff4607;
		font-family: "PingFangSC-regular";
	}
	.slogan-rank{
		width: 68px;
		height: 16px;
		border-radius: 2px;
		padding: 1px 4px;
		font-size: 12px;
		background: #fdefd2;
		color:#ae6e15;
		font-family: "PingFangSC-regular";
	}
	
	.container{
		display: flex;
		width: 155.6px;
		height: 106px;
	}
	.block-image1{
		position: relative;
		width: 155.600px;
		height: 84px;
		border-radius: 6px;
		overflow: hidden;
	}
	.image1{
		position: absolute;
		width: 155.600px;
		height: 84px;
	}
	.tag1{
		position: absolute;
		top: 0%;
		left: 0%;
		width: 54px;
		height: 14px;
		padding: 0px 3px;
		border-radius: 6px 0 6px 0;
		font-size: 10px;
		color: #fff;
		background: rgba(51, 51, 51,.8);
		font-family: "PingFangSC-regular,Tahoma";
	}
	.tag2{
		position: absolute;
		width: 143.600px;
		height: 20px;
		bottom: 6px;
		left: 6px;
		right: 6px;
		border-radius: 0 6px 0 6px;
		font-size: 11px;
		line-height: 12px;
		font-weight: 700;
		color: #fff;
	}
	.block-footer1{
		display: flex;
		margin-top: 4px;
		height: 18px;
		width: 155.600px;
	}
	.price{
		width: 30.025px;
		height: 18px;
		margin-right: 4px;
		color: #ff6600;
		font-family: "PingFangSC-regular,Tahoma";
		font-weight: bold;
		font-size: 16px;
	}
	.rank-wrapper{
		position: relative;
		display: flex;
		flex-direction: row;
	}
	.rank-item{
		margin-right: 2px;
	}
	.block-image{
		position: relative;
		width: 75.8px;
		height: 84px;
		border-radius: 6px;
		overflow: hidden;
	}
	.img{
		position: absolute;
		width: 75.8px;
		height: 84px;
	}
	.tag{
		position: absolute;
		top:0;
		left: 0;
		width: 24px;
		height: 14px;
		padding: 0px 3px; 
		border-radius: 6px 0 6px 0;
		font-size: 10px;
		background-image: linear-gradient(270deg,#f8e1bd,#e2c089);
		font-family: "PingFangSC-regular,Tahoma";
		color: #663c00;
	}
	.block-footer{
		display: flex;
		align-items: center;
		margin-top: 6px;
		width: 75.800px;
		height: 13.200px;
	}
	.rank-title{
		font-family: "PingFangSC-Semibold";
		font-size: 11px;
		color: #333;
		line-height: 1.1;
		height: 13.200px;
	}
	
	.ad-banner-wrap{
		width: 351.200px;
		height: 88px;
		padding: 0 12px 12px 12px;
		/* margin-top: 10px; */
		background-color: #fff;
	}
	.img_wrap{
		width: 351px;
		height: 88px;
		border-radius: 8px;
		overflow: hidden;
	}
	.img1{
		width: 351px;
		height: 88px;
	}
	
	.toolbox{
		width: 375.200px;
		height: 120px;
		padding-top: 12px;
		padding-bottom: 50px;
	}
	.tool-gruop{
		display: flex;
		justify-content: space-between;
		margin: 0 60px;
		height: 31.600px;
	}
	.tool-link{
		display: flex;
		justify-content: center;
		align-items: center;
		width: 100px;
		height: 30px;
		border: 1px solid #999;
		border-radius: 4px;
	}
	.img2{
		width: 13px;
		height: 12.8px;
		color: #666;
	}
	.t{
		width: 52px;
		height: 17px;
		color: #333;
		font-size: 13px;
		text-align: center;
		font-family: "PingFangSC-regular,Tahoma";
	}
	.sign{
		position:fixed;
		bottom: 100px;
		left: 299.200px;
		width: 76px;
		height: 76px;
	}
	
</style>
