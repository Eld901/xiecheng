<template>
	<view>
		<!-- 头部区域 -->
		<view class="header">		
			<view class="container">
				<view class="nav">
					<navigator url="../login/login" open-type="switchTab">
						<image src="/static/login/3.1 返回1.png" mode="heightFix" class="navimg1"></image>
						</navigator>
						
						<image src="/static/login/消息.png" mode="heightFix" class="navimg3"></image>
						</view>
				<view class="nav2">
							<view class="textview">{{lname}}</view>
				<view class="btg">
					<button class="btn" @click="onLogin">
						{{a1}}
					</button>
					<navigator url="../register/login">
						<button class="btn1">
						手机号查单
						</button>
					</navigator>	
						</view>
						<view class="logobox">
							<image :src="lgimg" mode="" class="lgimg"></image>
							<view class="lgview">{{lgname}}</view>
						</view>
						<view class="nav3">
											<view style="height: 1px;">
												<svg xmlns="http://www.w3.org/2000/svg" version="1.1">
													<line x1="0" y1="0" x2="400" y2="0" style="stroke:rgb(0,0,0);stroke-width:0.2"/>
												</svg>
											</view>
							<view class="box">
								<view class="tibox1">
									<image src="/static/login/_订单.png" mode="heightFix" class="imga"></image>
									<view class="tva">全部订单</view>
									</view>
									<view class="tibox2">
									<image src="/static/login/待付款.png"mode="heightFix" class="imgb"></image>
									<view class="tvb">待付款</view>
									</view>
									<view class="tibox3">
									<image src="/static/login/时钟.png" mode="heightFix" class="imgc"></image>
									<view class="tvc">未出行</view>
									</view>
									<view class="tibox4">
									 <image src="/static/login/待评价.png" mode="heightFix" class="imgc"></image>
									 <view class="tvd">待评价</view>
									</view>
									</view>
							
							<view class="box1">
							<view class="tv1">常用信息</view>
							 <image src="/static/login/向右1.png" mode="heightFix" class="img1"></image>
									</view>
									
									<view class="box2">
									<view class="tv2">我的收藏</view>
									 <image src="/static/login/向右1.png" mode="heightFix" class="img2"></image>
											</view>
											
											<view class="box3">
											<view class="tv3">浏览历史</view>
											 <image src="/static/login/向右1.png" mode="heightFix" class="img3"></image>
													</view>
													
													<view class="box4">
													<view class="tv4">我要合作</view>
													 <image src="/static/login/向右1.png" mode="heightFix" class="img4"></image>
															</view>
															
															<view class="box5">
															<view class="tv5">出行工具</view>
															 <image src="/static/login/向右1.png" mode="heightFix" class="img5"></image>
																	</view>
																	
																	<view class="boox">
																		<view class="hb">
																			<image src="/static/login/trust.png" mode="heightFix" class="imghb"></image>
																			<view class="tvhb">航班助手</view>
																			</view>
																			<view class="wd">
																			<image src="/static/login/金品专享.png"mode="heightFix" class="imgwd"></image>
																			<view class="tvwd">我的特权</view>
																			</view>
																			<view class="ys">
																			<image src="/static/login/logistics-airfreight-fill.png"mode="heightFix" class="imgys"></image>
																			<view class="tvys">一生旅行</view>
																			</view>
																			<view class="hd">
																			 <image src="/static/login/3D会场.png" mode="heightFix" class="imggd"></image>
																			 <view class="tvgd">更多</view>
																			</view>
																			</view>
									</view>

		</view>
		</view>
	</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				lgimg: "/static/login/头像 女孩.png",
				lgname: ""
			}
		},
		methods: {
			onLogin() {
				// 缓存外界的  this   方便后面使用
				let that = this;

				// 1.显示提示框
				// uni.showToast({
				// 	title:"登录成功",
				// 	icon:"fail",
				// 	duration:5000
				// })

				// 2.显示正在加载提示框
				// uni.showLoading({
				// 	title:"正在加载..."
				// })

				// 定时器 setTimeout(function() {}, 10);  第一个参数代表执行函数  第二个参数代表多少毫秒后执行前面的函数
				// setTimeout(function(){
				// 	// 关闭正在加载提示框
				// 	uni.hideLoading()
				// 	// 关闭正在加载提示框后 设置头像和昵称
				// 	that.lgimg = "/static/mine/tx.webp";
				// 	that.lgname = "小红";
				// },2000)
				
			



				// 3.模态框弹窗
				uni.showModal({
					title: "登录提示",
					content: "是否登录",
					success: function(res) {
						if (res.confirm) {
							uni.showLoading({
								title: "加载中..."
							})

							setTimeout(function() {
								uni.hideLoading()
								that.lgimg = "/static/头像 女孩.png";
								that.lgname = "尊敬的携程用户";
								that.lname="";
								that.a1="退出登录";
								
								uni.showToast({
									title:"登录成功"
								})
								
								// 需要存入一个缓存 表示登录 
								uni.setStorage({
									key:"islogin",
									data:"001",
									success:function(){
										console.log("缓存成功");
									}
								})
							}, 2000)
						} else if (res.cancel) {
							uni.showToast({
								title:"登录失败",
								icon:"error"
							})
						}

					}
				})
			}
		},
		// 生命周期
		// 页面加载的时候触发  只触发一次
		onLoad() {
			let that = this
			
			// 在页面加载的时候获取登录缓存
			uni.getStorage({
				// 通过key值获取缓存
				key:"islogin",
				success(res) {
					// res.data里面 就是 islogin对应的Key值、
					// 判断是否存在缓存
					if(res.data) {
						// 如果存在   直接设置头像和昵称
						that.lgimg = "/static/login/头像 女孩.png";
						that.lgname = "未登录";
						that.lname ="登录携程，开启旅程";
						that.a1="登录/注册";
					}
				}
			})
		},
		// 页面显示的时候触发
		onShow() {
			console.log("触发了 onshow");
		},
		// 页面加载完毕触发  只触发一次
		onReady() {
			console.log("触发了 onready");
		},
		// 页面隐藏 触发
		onHide() {
			console.log("触发了 onhide");
		}
	}
</script>

<style>
	.header {
		background-image: url(/static/login/back.png);
		background-color:#f5f5f5;
		background-repeat: no-repeat;
		background-size: 120% 180px;
	}
	
	.logobox {
		width:200px;
		height:30px;
		display: flex;
		justify-content: center;
		align-items: center;
		color: #7c7c7c;
	}
	.lgview{
		margin-bottom:30px;
		color: #fff;
	}
	
	.lgimg {
		width: 60px;
		height: 60px;
		border-radius: 50%;
		margin-right: 15px;
	}
	
	.container {
		width: 100%;
		margin: auto;
	}
	
	
	.nav {
		display: flex;
		justify-content: space-between;
		align-items: center;
		height: 45px;
	
	}
	
	.navimg1 {
		margin-left:20px;
		width: 15px;
		height: 20px;
	}
	
	.navimg3 {
		margin-right:20px;
		width: 15px;
		height: 20px;
	}
	
	.nav {
		justify-content: space-between;
		align-items: center;
		height: 45px;
		width: 100%;
	
	}
	
	.nav2 {
		justify-content: center;
		width: 100%;
		height: 120px;
	
	}
	
	.textview{
		text-align: center;
		height: 46px;
		font-size: 23px;
		line-height: 60px;
		color: white;
	}
	
	.btg {
	height: 50px;
	margin-top:10px;
	display: flex;
	align-items: center;
	justify-content: center;
	}
	
	.btn {
		width: 150px;
		height: 40px;
		margin-right: 30px;
		text-align: center;
		background-color:#ff9a10;
		color: white;
		font-size: 18px;
		line-height: 37px;
		border-radius: 30px;
	}
	
	.btn1 {
		width: 148px;
		height: 40px;
		margin-left: 30px;
		text-align: center;
		border:2px solid white;
		background-color:transparent;
		font-size: 18px;
		line-height: 35px;
		color: white;
		border-radius: 30px;

	}
	
	.nav3{
		margin-top: 20px;
		width: 100%;
		height: 500%;
	border-radius: 20px;
	background-color:#f5f5f5;
	}
	
	.box {
	margin-top: 1px;
	display: flex;
	align-items: center;
	justify-content: space-between;
	height: 50px;
	width: 100%;
	background-color: white;
	}
	
	.tibox1 {
	display: flex;
	flex-direction: column;
	justify-content: flex-end;
	align-items: center;
	width: 75px;
	height: 40px;
	}
	
	.tibox2 {
	display: flex;
	flex-direction: column;
	justify-content: flex-end;
	align-items: center;
	width: 75px;
	height: 40px;
	}
	
	.tibox3 {
	display: flex;
	flex-direction: column;
	justify-content: flex-end;
	align-items: center;
	width: 75px;
	height: 40px;
	}
	
	.tibox4 {
	display: flex;
	flex-direction: column;
	justify-content: flex-end;
	align-items: center;
	width: 75px;
	height: 40px;
	}
	
	.tva {
		color: black;
		font-size: 12px;
		margin-top: 2.5px;
	}
	
	.tvb {
		color: black;
		font-size: 12px;
		margin-top: 2.5px;
	}
	
	.tvc {
		color: black;
		font-size: 12px;
		margin-top: 2.5px;
	}
	
	.tvd {
		color: black;
		font-size: 12px;
		margin-top: 2.5px;
	}
	
	.imga {
		width: 20px;
		height: 25px;
	}
	
	.imgb {
		width: 20px;
		height: 25px;
	}
	
	.imgc {
		width: 20px;
		height: 25px;
	}
	
	.imgd {
		width: 20px;
		height: 25px;
	}
	
	.box1 {
	margin-top: 10px;
	display: flex;
	align-items: center;
	justify-content: space-between;
	height: 60px;
	width: 100%;
	background-color: white;
	}
	
	.tv1 {
		background-color: #fff;
		border-radius: 10px;
		padding-left: 10px;
	}
	
	.img1 {
		text-align: right;
		margin-right:10px;
		width: 15px;
		height: 20px;
	}
	//
	.box2 {
	margin-top: 1px;
	display: flex;
	align-items: center;
	justify-content: space-between;
	height: 60px;
	width: 100%;
	background-color: white;
	}
	
	.tv2 {
		background-color: #fff;
		border-radius: 10px;
		padding-left: 10px;
	}
	
	.img2 {
		margin-right:10px;
		width: 15px;
		height: 20px;
	}
	//
	.box3 {
		margin-top: 1px;
	display: flex;
	align-items: center;
	justify-content: space-between;
	height: 60px;
	width: 100%;
	background-color: white;
	}
	
	.tv3 {
		background-color: #fff;
		border-radius: 10px;
		padding-left: 10px;
	}
	
	.img3 {
		margin-right:10px;
		width: 15px;
		height: 20px;
	}
	//
	.box4 {
		margin-top: 1px;
	display: flex;
	align-items: center;
	justify-content: space-between;
	height: 60px;
	width: 100%;
	background-color: white;
	}
	
	.tv4 {
		background-color: #fff;
		border-radius: 10px;
		padding-left: 10px;
	}
	
	.img4 {
		margin-right:10px;
		width: 15px;
		height: 20px;
	}
	//
	.box5 {
	margin-top: 10px;
	display: flex;
	align-items: center;
	justify-content: space-between;
	height: 60px;
	width: 100%;
	background-color: white;
	}
	
	.tv5 {
		background-color: #fff;
		border-radius: 10px;
		padding-left: 10px;
	}
	
	.img5 {
		margin-right:10px;
		width: 15px;
		height: 20px;
	}
	
	.boox {
	margin-top: 10px;
	display: flex;
	align-items: center;
	justify-content: space-between;
	height: 100px;
	width: 100%;
	background-color: white;
	}
	
	.hb {
	display: flex;
	flex-direction: column;
	align-items: center;
	width: 50px;
	height: 40px;
	}
	
	.wd {
	display: flex;
	flex-direction: column;
	align-items: center;
	width: 50px;
	height: 40px;
	}
	
	.ys {
	display: flex;
	flex-direction: column;
	align-items: center;
	width: 50px;
	height: 40px;
	}
	
	.gd {
	display: flex;
	flex-direction: column;
	align-items: center;
	width: 50px;
	height: 40px;
	}
	
	.tvhb {
		color: black;
		font-size: 12px;

	}
	
	.tvwd {
		color: black;
		font-size: 12px;
	}
	
	.tvys {
		color: black;
		font-size: 12px;
	}
	
	.tvgd {
		color: black;
		font-size: 12px;
	}
	
	.imghb {
		width: 40px;
		height: 25px;
	}
	
	.imgwd {
		width: 40px;
		height: 25px;
	}
	
	.imgys {
		width: 40px;
		height: 25px;
	}
	
	.imggd {
		width: 40px;
		height: 25px;
	}
</style>