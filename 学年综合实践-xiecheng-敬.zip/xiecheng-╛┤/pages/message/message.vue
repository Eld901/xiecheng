<template>
	<view class="general">
		<view class="container1">
				<navigator url="../index/index" open-type="switchTab">
				<image src="/static/message/返回.png" mode="" class="return"></image>
				</navigator>
				<view class="title">消息</view>
		</view>

		<view class="occupy"></view>
		<view class="container2">

				<view class="navbox">
					
					<view class="navson" >
						<view class="navbtn" v-for="(item,index) in navarr">
							<image :src="item.navimg" mode="" class="btnic"></image>
							<view class="btntext">{{item.navtext}}</view>
							<view class="reddot" v-if="item.isnew"></view>
							
							<navigator :url="item.url" open-type="navigate" class="click2" :data-id="item.id" @click="click2"></navigator>
							<!-- <view class="click2" :data-id="item.id" @click="click2"></view> -->
						</view>
					</view>
				</view>
				
		</view>
		
		<view class="container3">
			<view class="chatgroup">
				
					<!-- <view class="chatson" data-id="1" @click="click">
						<image src="/static/message/6hd.jpg" mode="" class="hd" ></image>
						<view class="ctreddot"></view>
						<view class="chatext">
							<view class="info">
								<view class="time">11:00</view>
								<view class="name">徐磊和Ta的团队</view>
								<view class="note">
									<view class="nttext">发现新内容</view>
									<image src="/static/message/8note.png" mode="" class="ntimg" ></image>
								</view>
							</view>
							<view class="content">您好，很高兴为您服务。把您的问题告诉我，...</view>
						</view>
					</view>
					
					<view class="chatson" data-id="2" @click="click">
						<image src="/static/message/7hd.png" mode="" class="hd" ></image>
						<view class="ctreddot"></view>
						<view class="chatext">
							<view class="info">
								<view class="time">00:27</view>
								<view class="name">消息号动态</view>
								<view class="note">
									<view class="nttext">发现新内容</view>
									<image src="/static/message/8note.png" mode="" class="ntimg" ></image>
								</view>
							</view>
							<view class="content">特价专区：盛夏旅行季，一起结伴同行吧！</view>
						</view>
					</view> -->
				
					<view class="chatson" v-for="(item,index) in chatarr" >
						
						<image :src="item.imgsrc" mode="" class="hd" ></image>
						<view class="ctreddot" v-if="item.isnew"></view>
						<view class="chatext" >
							<view class="info" >
								<view class="time" >{{item.time}}</view>
								<view class="name" >{{item.name}}</view>
								<view class="note" >
									<view class="nttext" v-if="item.isnew" >发现新内容</view>
									<image src="/static/message/8note.png" mode="" class="ntimg" v-if="item.isnew" :data-id="item.id" @click="click"></image>
								</view>
							</view>
							<view class="content">{{item.content}}</view>
						</view>
						
						<!-- <view class="click" :data-id="item.id" @click="click"></view> -->
						<navigator url="../chat/chat" open-type="switchTab" class="click" :data-id="item.id" @click="click"></navigator>
					</view>
					
				
			</view>
		</view>
		
		<view class="nomore">
			没有更多内容了
		</view>
		
		<navigator url="../chat/chat" open-type="switchTab">
		<view class="kfbox">
			<image src="/static/message/9在线咨询.png" mode="" class="kfmg"></image>
			<view class="kftext">客服</view>
		</view>
		</navigator>
		
	</view>
</template>

<script>
	export default {
		data() {
			return {
				navarr:[
					{
						id:0,
						navimg:"/static/message/1订单出行.png",
						navtext:"订单出行",
						isnew:1,
						url:"../orders/orders"
					},
					{
						id:1,
						navimg:"/static/message/2互动消息.png",
						navtext:"互动消息",
						isnew:1,
						url:"../interaction/interaction"
					},
					{
						id:2,
						navimg:"/static/message/3账户通知.png",
						navtext:"账户通知",
						isnew:0,
						url:"../account/account"
					},
					{
						id:3,
						navimg:"/static/message/4会员服务.png",
						navtext:"会员服务",
						isnew:1,
						url:"../member/member"
					}
				],
				
				chatarr:[
					{
						id:0,
						imgsrc:"/static/message/6hd.jpg",
						time:"11:00",
						name:"徐磊和Ta的团队",
						content:"您好，很高兴为您服务。把您的问题告诉我，...",
						isnew:1
					},
					{
						id:1,
						imgsrc:"/static/message/7hd.png",
						time:"00:27",
						name:"消息号动态",
						content:"特价专区：盛夏旅行季，一起结伴同行吧！",
						isnew:1
					},
					{
						id:2,
						imgsrc:"/static/logo.png",
						time:"16:05",
						name:"对象",
						content:"xxx...",
						isnew:1
					}
					,
					{
						id:3,
						imgsrc:"/static/logo.png",
						time:"16:05",
						name:"对象1",
						content:"xxx...",
						isnew:0
					},
					{
						id:4,
						imgsrc:"/static/logo.png",
						time:"16:05",
						name:"对象2",
						content:"xxx...",
						isnew:1
					},
					{
						id:5,
						imgsrc:"/static/logo.png",
						time:"16:05",
						name:"对象3",
						content:"xxx...",
						isnew:0
					},
					
				]
			}
		},
		methods: {
			click(e) {
				// let index = e.target.dataset.id
				console.log(this.chatarr[e.target.dataset.id].isnew);
				//this.chatarr[index].isnew
				this.chatarr[e.target.dataset.id].isnew=0
				// this.chatarr[index].isnew=0
			},
			click2(e) {
				
				console.log(this.navarr[e.target.dataset.id].isnew);
				
				this.navarr[e.target.dataset.id].isnew=0
				
			}
		}
	}
</script>

<style>
	.general {
		height: 667px;
		background-color: #f8f8f8;
		background-image:url("/static/message/5bgimg.png");
		background-repeat: no-repeat;
		background-size: 100%;
		background-position: top;
	}
	
	.container1 {
		width: 100%;
		height: 44px;
		
		display: flex; //放在水平主轴上
		align-items: center; //垂直居中
		justify-content: center;
		position: fixed;
	}
	
	.return {
		width: 22px;
		height: 22px;
		
		position: absolute;//控制return返回键相对于模拟器顶部和左部的位置
		top:13px;
		left:11px;  
	}
	.title {
		font-size: 17px;
	}
	
	.occupy {
		height: 44px;
	}
	.container2 {
		
		height: 101px;
		margin-top: 12px;
		padding-bottom: 12px;	
	}

	.navbox {
		height: 89px;
		margin: 0 12px;
		padding-bottom: 12px;
		border-radius: 12px;
		background-color: white;
	}
	.navson {
		height: 69px;
		padding: 16px 30px 4px 30px;
		display: flex;
		justify-content: space-between;//主轴上均匀分布
	}
	.click2 {
		width: 52px;
		height: 69px;
		position: absolute;
		background-color:transparent;
	}
	.navbtn {
		width: 52px;
		height: 69px;
		display: flex;
		justify-content: space-between;
		flex-direction: column;//改主轴为垂直,使图片按钮和文字竖向排列
		align-items: center;//(水平的)交叉轴上居中
		position: relative;
	}
	.btnic {
		width: 44px;
		height: 44px;
	}
	.reddot{
		position: absolute;
		top:2px;
		right: 3px;
		width: 8px;
		height: 8px;
		border: 0.8px solid #fff;
		background-color: #f5190a;
		border-radius: 50%;
	}
	.btntext {
		width: 52px;
		height: 17px;
		font-size: 13px;
	}
	

	.chatson {
		height: 70.8px;
		padding-left: 16px;
		display: flex;
		align-items: center;
		background-color: white;
		position: relative;
	}
	
	.click {
		width: 100%;
		height: 70.8px;
		position: absolute;
		background-color:transparent;
	}
	.hd {
		width: 44px;
		height: 44px;
		border-radius: 50%;
	}
	.ctreddot{
		position: absolute;
		top:14px;
		left: 50px;
		width: 8px;
		height: 8px;
		border: 0.8px solid #fff;
		background-color: #f5190a;
		border-radius: 50%;
	}
	.chatext{
		height: 46px;
		padding: 12px 0;
		margin-left: 16px;
		display: flex;
		flex-direction: column;
		justify-content: space-between;
		
	}
	.info {
		display: flex;
		align-items: center;
	}
	.time {
		
		color: #ccc;
		font-size: 12px;
		position: absolute;
		right: 16px;
	}
	.name {
		height: 22.5px;
		font-weight: bold;
		font-size: 15px;
		color: #333;
	}
	.content {
		height: 19.5px;
		margin-top: 4px;
		margin-right: 16px;
		font-size: 13px;
		color: #999;
		
		
	}
	.note {
		width: 82.5px;
		height: 20px;
		margin-left: 11.5px;
		border-radius: 10px;
		display: flex;
		position: relative;
	}
	.ntimg {
		position: absolute;
		left: 0;
		width: 18px;
		height: 18px;
		background-color: white;
		border-radius: 50%;
	}
	
	.nttext {
		position: absolute;
		left: 18px;
		width: 60px;
		height: 15px;
		line-height: 15px;
		padding: 2px 6px 2px 13px;
		margin-left: -10px;
		font-size: 12px;
		background-color: #e6f8f1;
		color: #00b87a;
		border-radius: 10px;
	}
	
	.nomore {
		height: 40px;
		line-height: 40px;
		text-align: center;
		color: grey;
		font-size: 14px;
	}
	
	.kfbox {
		width: 48px;
		height: 34px;
		padding: 7px 0;
		
		border-radius: 50%;
		background-color: pink;
		position: fixed;
		
		bottom: 70px;
		right: 20px;
		display: flex;
		flex-direction: column;
		align-items: center;
		justify-content: space-between;
		background-color: #fff;
		box-shadow: 0 3px 1px 1px rgba(0,0,0,.11);

	}
	.kfmg {
		
		width: 19px;
		height: 19.2px;
		font-size: 19px;
	}
	.kftext {
		width: 48px;
		height: 12px;
		
		line-height: 12px;
		text-align: center;
		font-size: 11px;
	}
	
	

</style>
