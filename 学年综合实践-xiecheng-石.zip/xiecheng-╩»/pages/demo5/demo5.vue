<template>
	<view>
		<view class="la">
			<view class="la1">
				<view class="la2">
			    	<view class="x1">汽车票</view>
		     		<view class="x1">船票/游船</view>
		    		<view class="x1">旅游专线</view>
		     		<view class="x1">机场跨城</view>			
		     	</view>
		     </view>
		</view>
		<view class="q">
			<view class="xz">
		    	<view class="cs">
					<input type="text" class="cs1" placeholder="出发城市">
					<image src="../../static/demo5/74-交换.png" class="cs2"></image>
					<input type="text" class="cs1" placeholder="到达城市">
		    	</view>
	     		<view class="date">
					<view class="date1">06月18日 周日</view>
					<view class="date2">今天</view>
	    		</view>
	     		<view class="cx">
	    			<view class="cx1" @click="getC">查询</view>
		    	</view>
	    	</view>
		</view>
		
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			}
		},
		methods: {
			getC(){
				uni.showToast({
					title:"查询成功",
					icon:"success",
					duration:1000
				})
			}
		}
	}
</script>

<style>
	
	.la{
		width: 375.200px;
		height: 180px;
		background-image: url(/static/demo5/bus-h5-ad-banner.png);
		background-size: 100% 100%;
	}
	.la1{
		display: flex;
		width: 355.200px;
		height: 30px;
		justify-content: center;
		position:absolute;
		top: 130px;
		
	}
	.la2{
		display: flex;
		width: 320.200px;
		height: 25px;
		flex-direction: row;
		padding: 10px;
		position: absolute;
		top: 10px;
		left: 18px;
		border-radius: 10px 10px 0 0;
		justify-content: space-between;
		background-color: #fff;
	}
	.x1{
		margin: 2px;
		background-color: #fff;
		font-family: "宋体";
		font-size: 15px;
		font-weight: bold;
		color: #333;
	}
	.q{
		display: flex;
		background-color: #f8f8f8;
		flex-direction: column;
		width: 375.200px;
		height: 175px;
	}
	.xz{
		width: 324.200px;
		height: 175px;
		padding: 0 8px;
		position: absolute;
		left: 18px;
		border-radius: 0 0 10px 10px;
		background-color: #fff;
	}
	.cs{
		display: flex;
		flex-direction: row;
		justify-content: space-between;
		align-items: center;
		width: 335.200px;
		height: 60px;
	}
	.cs1{
		width: 152.600px;
		height: 26.400px;
		font-weight: bold;
		color: #999;
		font-family: "宋体";
		padding-top: 7px;
		text-align: center;
		font-size: 20px;
	}
	.cs2{
		width: 30px;
		height: 30px;
	}
	.date{
		display: flex;
		flex-direction: row;
		align-items: center;
		width: 335.200px;
		height: 47px;
	}
	.date1{
		width: 131.538px;
		height: 33px;
		font-size: 16px;
		font-weight: bold;
		color: #000;
		font-family: "宋体";
		padding-top: 14px;
		padding-left: 20px;
		text-align: center;
	}
	.date2{
		width: 28px;
		height: 31px;
		font-weight: normal;
		font-size: 10px;
		color: #999;
		margin-left: 10px;
		text-align: center;
		font-family: "宋体";
		padding-top: 16px;
	}
	.cx{
		display: flex;
		width: 335.200px;
		height: 44px;
		
	}
	.cx1{
		width: 325.200px;
		height: 44px;
		border-radius: 10px;
		justify-content: center;
		background: linear-gradient(to right,#ffa50a,#f70);
		font-size: 20px;
		font-family: "宋体";
		color: #fff;
		text-align: center;
		font-weight: bold;
		line-height: 45px;
	}
</style>
