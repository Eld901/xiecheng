<template>
	<view>
		<view class="container1">
				<navigator url="../orders/orders">
				<image src="/static/message/返回.png" mode="" class="return"></image>
				</navigator>
				<view class="toptitle">订单详情</view>
				<view class="left">
					<image src="/static/detail/退改说明.png" mode="" class="smimg"></image>
					<view class="sm">退改说明</view>
				</view>
				<view class="right">
					<navigator url="../chat/chat" open-type="switchTab">
					<image src="/static/detail/客服.png" mode="" class="kfimg"></image>
					<view class="kf">客服</view>
					</navigator>
				</view>
		</view>
		
		<view class="container2">
			<view class="c2box">
				<image src="/static/detail/已退票.png" mode="" class="c2img"></image>
				<view class="c2text">
					<view class="c2title">
						已退票
					</view>
					<view class="c2content">
						已为您退票，感谢您使用携程火车票
					</view>
				</view>
			</view>
			
			<view class="moneybox">
				<image src="/static/detail/ic_moneybag.png" mode="" class="mnimg"></image>
				<view class="mntext">戳我有机会赢本单免单，更有其他惊喜等你拿</view>
				<image src="/static/detail/前进.png" mode="" class="mngo"></image>
			</view>
			
			<view class="c2tkt">
				<view class="c2info">
					<view class="infotop">
						订单号: EH25513903
					</view>
					<view class="infocenter">
						<view class="from">
							<view class="date" data-key="date">4月29日 周六</view>
							<view class="time" data-key="time">18:16</view>
							<view class="station" data-key="station">南充站</view>
						</view>
						<view class="mid">
							<view class="checi">
								K529
							</view>
							<view class="jingting">
								经停信息
							</view>
						</view>
						<view class="to">
							<view class="date" data-key="date">4月29日 周六</view>
							<view class="time" data-key="time">18:57</view>
							<view class="station" data-key="station">成都站</view>
						</view>
					</view>
					<view class="infobtm">
						<view class="tkthd">
							<view class="tkname">小明
								<view class="tktag">学生票</view>
							</view>
							<view class="rbox">03车厢083号</view>
						</view>
						<view class="tktbd">
							<view class="blue-tag">
								改签
							</view>
							<view class="cert">
								身份证 512021**********21
							</view>
							<view class="rprice">
								硬座  ¥6.5
							</view>
						</view>
						<view class="tktft">
								退票成功
						</view>
					</view>
				</view>
			</view>
		
			
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			}
		},
		methods: {
			
		}
	}
</script>

<style>
	.container1 {
		width: 100%;
		height: 44px;
		display: flex; 
		align-items: center; 
		justify-content: center;
		position: fixed;
	}
	.return {
		width: 22px;
		height: 22px;
		position: absolute;
		top:13px;
		left:11px;  
	}
	.toptitle {
		font-size: 17px;
	}
	.left {
		width: 50px;
		height: 32px;
		display: flex;
		flex-direction: column;
		align-items: center;
		position: absolute;
		right:50px;
	}
	.smimg{
		width: 20px;
		height: 20px;
		position: absolute;
	}
	.sm{
		width: 48px;
		height: 18px;
		font-size: 10px;
		margin-top: 1px;
		position: absolute;
		top: 20px;
	}
	.right {
		width: 32px;
		height: 32px;
		display: flex;
		flex-direction: column;
		align-items: center;
		position: absolute;
		right: 12px;
	}
	.kf {
		width: 24px;
		height: 18px;
		font-size: 10px;
		margin-top: 1px;
		position: absolute;
		top: 19px;
	}
	.kfimg {
		width: 20px;
		height: 20px;
		position: absolute;
	}
	.container2 {
		position: absolute;
		height: 623px;
		top:44px;
		background-color: #f8fafd;
	}
	.c2box {
		width: 335.2px;
		height: 58px;
		padding: 24px 20px;
		border-bottom: 8px;
		display: flex;
		align-items: center;
		justify-content: space-between;
		background-color: white;
	}
	.c2img {
		width: 40px;
		height: 40px;
	}
	.c2text {
		width: 283.2px;
		height: 58px;
		display: flex;
		flex-direction: column;
	}
	.c2title {
		width: 283.2px;
		height: 56px;
		font-size: 23px;
		font-weight: 700;
		color: #0086f6;
	}
	.c2content {
		width: 283.2px;
		height: 20px;
		margin-top: 2px;
		color: #666;
		font-size: 14px;
	}
	
	.moneybox {
		width: 359.2px;
		height: 44px;
		margin: 8px;
		background-color: pink;
		display: flex;
		align-items: center;
		border-radius: 12px;
		background-color: white;
	}
	.mnimg {
		width: 24px;
		height: 24px;
		padding: 12px 13px;
	}
	.mntext {
		width: 271.2px;
		height: 20px;
		padding: 12px 0;
		font-size: 14px;
		color: #f70;
	}
	.mngo {
		width: 14px;
		height: 20px;
		padding: 12px;
	}
	.c2tkt {
		width: 359.2px;
		height: 265px;
		margin: 0 8px 8px 8px;
	}
	.c2info {
		width: 335.2px;
		height: 229px;
		padding: 18px 12px;
		background-color:white;
		position: relative;
		border-radius: 12px;
	}
	.infotop {
		width: 335.2px;
		height: 18px;
		margin-bottom: 16px;
		font-size: 12px;
		color: #ccc;
		
	}
	.infocenter {
		width: 335.2px;
		height: 73px;
		margin-bottom: 16px;
		display: flex;
		align-items: center;
	}
	.from{
		width: 112.6px;
		height: 73px;
	}
	.date {
		font-size: 12px;
		color: #ccc;
	}
	.time {
		font-size: 28px;
		font-weight: 700;
		color: #ccc;
		
	}
	.station {
		font-size: 14px;
		font-weight: 700;
		color: #ccc;
	}
	.mid{
		width: 110px;
		height: 49px;
		text-align: center;
	}
	.checi {
		width: 110px;
		height: 18px;
		font-size: 12px;
		color: #ccc;
		text-align: center;
	}
	.jingting {
		width: 112px;
		height: 21px;
		margin: 2px -2px 8px 0;
		font-size: 12px;
		color: #5678a8;
		background-image: url(/static/detail/jingting-bg.png);
		background-size: cover;
		background-repeat: no-repeat;
	}
	.to {
		width: 112.6px;
		height: 73px;
		text-align: end;
	}
	.infobtm {
		width: 311.2px;
		height: 82px;
		padding: 12px;
		margin-top: 16px;
		background-color:#f8fafd;
		border-radius: 12px;
	}
	.tkthd {
		width: 311.2px;
		height: 24px;
		color: #ccc;
		display: flex;
		justify-content: space-between;
	}
	.tkname {
		width: 104px;
		height: 24px;
		font-size: 16px;
		font-weight: bolder;
		display: flex;
		align-items: center;
	}
	.tktag {
		width: 36px;
		height: 16px;
		padding: 0 4px;
		margin: 0 4px 0 8px;
		border-radius: 2px;
		background-color: #fff;
		font-size: 11px;
	}
	.rbox {
		width: 86.575px;
		height: 21px;
		font-size: 14px;
		font-weight: bolder;
	}
	.tktbd {
		width: 311.2px;
		height: 18px;
		margin-top: 2px;
		color: #ccc;
		display: flex;
		justify-content: space-between;
		align-items: center;
		
	}
	.blue-tag {
		font-weight: bolder;
		width: 24px;
		height: 16px;
		padding: 0 5px;
		position: absolute;
		top: 0;
		left: 0;
		color: white;
		font-size: 10px;
		border-radius: 12px 1px 10px;
		background-color: #1890ff;
	}
	.cert {
		font-size: 12px;
		height: 18px;
		
	}
	.rprice {
		font-size: 12px;
		height: 18px;
	}
	.tktft {
		width: 311.2px;
		height: 30px;
		font-size: 13px;
		line-height: 30px;
		color: #00b87a;
	}
	

</style>
