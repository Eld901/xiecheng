<template>
	<view>
		<view class="container1">
				<navigator url="../message/message" open-type="switchTab">
				<image src="/static/message/返回.png" mode="" class="return"></image>
				</navigator>
				<view class="title">互动消息</view>
		</view>
		
		<view class="container2">
			<view class="name" v-for="(item,index) in navarr">
				{{item.name}}
			</view>
			
		</view>
		

		<view class="container3">
			<scroll-view scroll-x="true" scroll-with-animation >
				<view class="c3box">
					<view class="c3">
					<image src="/static/interaction/img.png" mode="" class="img"></image>
					<view class="txt">暂无内容</view>
					</view>
					<view class="c3">
					<image src="/static/interaction/img.png" mode="" class="img"></image>
					<view class="txt">暂无内容</view>
					</view>
					<view class="c3">
					<image src="/static/interaction/img.png" mode="" class="img"></image>
					<view class="txt">暂无内容</view>
					</view>
				</view>
			</scroll-view>
		</view>
		
		
		<view class="container4">
			<navigator :url="item.url" open-type="switchTab" class="name n2" v-for="(item,index) in btmarr" :data-id="item.id">
				{{item.name}}
			</navigator>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				"navarr":[
					{
						id:1,
						name:"通知"},
					{
						id:2,
						name:"赞"},
					{
						id:3,
						name:"评论和@"},
					{
						id:4,
						name:"收藏"},
					{
						id:5,
						name:"新增粉丝"}
				],
				"btmarr":[
					{
						id:1,
						name:"个人主页",
						url:"../login/login"
					},
					{
						id:2,
						name:"社区频道",
						url:"../shequ/shequ"
					},
					{
						id:3,
						name:"活动广场",
						url:"../demo1/demo1"
					}
				]
			}
		},
		methods: {
			
		}
	}
</script>

<style>
	.container1 {
		width: 100%;
		height: 44px;
		border-bottom: 0.5px solid lightgray;
		display: flex; //放在水平主轴上
		align-items: center; //垂直居中
		justify-content: center;
		position: fixed;
	}
	.return {
		width: 22px;
		height: 22px;
		position: absolute;//控制return返回键相对于模拟器顶部和左部的位置
		top:13px;
		left:11px;  
	}
	.title {
		font-size: 17px;
	}
	
	.container2 {
		width: 335.2px;
		height: 42.2px;
		padding: 0 20px;
		padding-bottom: 1px;
		position: fixed;
		top: 44px;
		display: flex;
		justify-content: space-between;
		
	}
	.name {
		height: 18px;
		padding: 12px 0;
		font-size: 13px;
	}
	.n2 {
		font-size: 14px;
		
	}

	
	.container3 {
		width: 343.2px;
		height: 519.2px;
		padding: 8px 16px;
		position: fixed;
		bottom: 52.2px;
	}
	.c3box {
		display: flex;
	}
	.c3 {
		padding: 0 102.5px;
		height: 519.2px;
		display: flex;
		flex-direction: column;
		align-items: center;
		justify-content: center;
		background-color: #f8f8f8;
	}
	.img {
		width: 170px;
		height: 170px;	
	}
	.txt {
		width: 60px;
		height: 22.5px;
		font-size: 15px;
		color: rgb(51, 51, 51);
	}
	.container4 {
		width: 315.2px;
		height: 32.2px;
		padding: 10px 30px;
		border-top: 0.8px solid lightgrey;
		position: fixed;
		bottom: 0;
		display: flex;
		justify-content: space-between;
		align-items: center;
	}

</style>
