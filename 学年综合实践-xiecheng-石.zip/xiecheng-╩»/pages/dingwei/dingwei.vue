<template>
	<view>
		<image src="../../static/shequ/left-arrow.png" mode="" class="imgl" @click="turnback"></image>
		<view class="t1">当前</view>
		<view class="line"></view>
		<view class="dw">
			<image src="../../static/shequ/感叹号中.png" mode="" class="im1"></image>
			<view class="t2">定位未开</view>
		</view>
		<view class="line"></view>
		<view class="t1">热门推荐</view>
		<view class="remen">
			<view class="line1">
				<view class="bj">
					<view class="t3">北京</view>
					<view class="t4">中国</view>
				</view>
				<view class="bj">
					<view class="t3">上海</view>
					<view class="t4">中国</view>
				</view>
				<view class="bj">
					<view class="t3">杭州</view>
					<view class="t4">浙江</view>
				</view>
			</view>
			<view class="line1">
				<view class="bj">
					<view class="t3">成都</view>
					<view class="t4">四川</view>
				</view>
				<view class="bj">
					<view class="t3">青岛</view>
					<view class="t4">山东</view>
				</view>
				<view class="bj">
					<view class="t3">南京</view>
					<view class="t4">江苏</view>
				</view>
			</view>
			<view class="line1">
				<view class="bj">
					<view class="t3">广州</view>
					<view class="t4">广东</view>
				</view>
				<view class="bj">
					<view class="t3">东京</view>
					<view class="t4">日本</view>
				</view>
				<view class="bj">
					<view class="t3">深圳</view>
					<view class="t4">中国</view>
				</view>
			</view>
		</view>
		<view class="A">A</view>
		<view class="A1">阿坝藏族羌族自治州，四川</view>
		<view class="line"></view>
		<view class="A1">阿布扎比，阿联酋</view>
		<view class="line"></view>
		<view class="A1">阿德莱德，澳大利亚</view>
		<view class="line"></view>
		<view class="A1">阿尔山，兴安盟</view>
		<view class="line"></view>
		<view class="A1">阿格拉，印度</view>
		<view class="line"></view>
		<view class="A1">爱丁堡，英国</view>
		<view class="line"></view>
		<view class="A1">埃勒，斯里兰卡</view>
		<view class="line"></view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			}
		},
		methods: {
			turnback(){
				uni.switchTab({
					url:'/pages/shequ/shequ'
				});
			}
			
		}
	}
</script>

<style>
	.imgl{
		height: 30px;
		width: 30px; 
	}
	.t1{
		height: 40px;
		width: 100%;
		font-weight: bold;
		color: #333333;
		margin-top: 10px;
		margin-left: 10px;
	}
	.dw{
		display: flex;
		height: 65px;
		width: 100%;
		
	}
	.im1{
		width: 20px;
		height: 20px;
		align-items: center;
		margin-top: 25px;
	}
	.t2{
		width: 100%;
		height: 24px;
		color: #333333;
		font-size: 20px;
		font-weight: bold;
		align-items: center;
		margin-top: 20px;
	}
	.remen{
		height: 200px;
		width: 100%;
	}
	.bj{
		background-color: aliceblue;
		height: 45px;
		width: 105px;
		margin-left: 15px;
		margin-top: 15px;
	}
	.t3{
		font-size: 15px;
		align-items: center;
		margin-left: 30px;
	}
	.t4{
		font-size: 10px;
		color: lightgray;
		align-items: center;
		margin-left: 32px;
	}
	.line1{
		display: flex;
		justify-content: space-between;
	}
	.A{
		height: 25px;
		width: 100%;
		background-color:lightgray;
	}
	.A1{
		height: 25px;
		width: 100%;
		margin-top: 10px;
		margin-bottom: 10px;
	}
	.line{
		border-bottom: 1px solid lightgrey;
		height: 1px;
	}

</style>
