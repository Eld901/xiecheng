<template>
	<view>
		<view class="general" >
			<view class="in" >
				<input type="text" v-model="ipt">
			</view>
			<view class="btn" @click="clear">
				按钮
			</view>
			<navigator url="../orders/orders">
				<view class="btn1">order</view></navigator>
			<navigator url="../interaction/interaction">
			<view class="btn2" >interaction</view></navigator>
			<navigator url="../account/account">
			<view class="btn3">account</view></navigator>
			<navigator url="../member/member">
			<view class="btn4" >member</view></navigator>
			
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				ipt:""
			}
		},
		methods: {
			clear() {
				let getipt =this.ipt;
				this.ipt = "";
			}
		}
	}
</script>

<style>
	
	.general {
		
		height: 667px;
		background-color: pink;
		background-image:url("/static/message/5bgimg.png");
		background-repeat: no-repeat;
		background-size: 100%;
		background-position: top;
	}
	.in {
		height: 44px;
		background-color: aquamarine;
		display: flex;
		align-items: center; //垂直居中
		justify-content: center;
		top: 0px;
		
	}
	.btn {
		width: 200px;
		height: 30px;
		background-color: powderblue;
		border-radius: 10px;
		text-align: center;
	}
	.btn1 {
		width: 200px;
		height: 30px;
		background-color: powderblue;
		border-radius: 10px;
		text-align: center;
	}
	.btn2 {
		width: 200px;
		height: 30px;
		background-color: powderblue;
		border-radius: 10px;
		text-align: center;
	}
	.btn3 {
		width: 200px;
		height: 30px;
		background-color: powderblue;
		border-radius: 10px;
		text-align: center;
	}
	.btn4 {
		width: 200px;
		height: 30px;
		background-color: powderblue;
		border-radius: 10px;
		text-align: center;
	}
	

</style>
