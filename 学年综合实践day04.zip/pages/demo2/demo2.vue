<template>
	<view>
		<!-- 数据绑定   v-bind -->
		<!-- 标签属性 :属性 = "变量" -->
		<!-- 标签内部  {{变量}} {{语句}}-->
		
		
		<!-- 注意：变量需要定义在  data return 里面 -->
		 <view  :class="classdemo">今天{{1+2}}</view>
		 
		 <!-- 
		 事件 
		 事件三要素：
		  1.事件源    开关
		  2.事件   用手按
		  3.事件处理函数  灯亮了
		  
		  用手按开关，灯亮了
		 -->
		 <!-- 
		    绑定事件   v-on  简写  @
			绑定点击事件   @click="函数名"
		  -->
		  
		  <view class="btn" @click="getClass">按钮</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				day:"星期四",
				classdemo:"son"
			}
		},
		methods: {
			getClass(){
				// 通过this来获取data里面的值
				// console.log(this.day);
				// console.log(this.classdemo);
				
				this.classdemo = "fa"
			}
		}
	}
</script>

<style>
     .fa {
		 width: 200px;
		 height: 200px;
		 background-color: pink;
	 }
	 
	 .son {
		 width: 300px;
		 height: 300px;
		 background-color: red;
	 }
	 
	 .btn {
		 width: 80px;
		 height: 30px;
		 border-radius: 10px;
		 background-color: aquamarine;
		 color: #fff;
		 font-weight: bold;
		 text-align: center;
		 line-height: 30px;
	 }
</style>
