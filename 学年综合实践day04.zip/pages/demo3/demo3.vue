<template>
	<view>
		<!-- 
		   v-for 列表渲染
		      v-for="(item,index) in 数组"
			  item代表数组里面的每一项
			  index代表数组的下标
		 -->
		<!-- <view v-for="(item,index) in arr1">{{item}}+{{index}}</view> -->
		<view v-for="(item,index) in arr2">我叫{{item.name}},我来自{{item.city}},我喜欢玩{{item.hobby}}</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				arr1: [1, 2, 3, 4, 5],
				arr2: [
					{
						name: "小明",
						city: "南充",
						hobby: "王者"
					},
					{
						name: "小军",
						city: "绵阳",
						hobby: "原神"
					},
					{
						name: "小红",
						city: "成都",
						hobby: "明日方舟"
					},
					{
						name: "小芳",
						city: "遂宁",
						hobby: "qq飞车"
					}
				]
			}
		},
		methods: {

		}
	}
</script>

<style>

</style>