<template>
	<view>

	</view>
</template>

<script>
	// 引用数据类型  array(数组)  object(对象)  function(函数)

	// array  数组
	/* 
	   1.定义数组  []
	 */
	let arr1 = [];
	let arr2 = [100, "哈哈", true, null, undefined, [1, 2, 3], {}, function() {}];

	/* 
	   2.数组取值  用下标   下标从0开始 
	   数组名[下标]
	 */
	let arr3 = [1, 2, 3, 4, 5, 6, 7, 8, 9, 0]

	console.log(arr3[1]); //2
	/* 
	  3.数组内置方法  length   获取数组的长度
	 */

	console.log(arr3.length); // 10

	console.log(arr3[arr3.length - 1]); //获取到数组的最后一项  0

	/* 
	  4.数组的内置方法  push(数据)   往数组里面追加数据 
	 */

	console.log(arr3);

	arr3.push(11)

	console.log(arr3);


	//  object  对象
	/* 
	   1.定义对象   {}
	 */
	let obj1 = {}

	let obj2 = {
		id: 1,
		name: 'xioo',
		hobby: ["学习", "上课", "睡觉"],
		city: {
			code: "nc",
			name: "南充"
		}
	}

	/* 
	   2.对象取值   用点语法 
	 */

	console.log(obj2.name); //xioo

	console.log(obj2.hobby[2]); //睡觉

	console.log(obj2.city.name); //南充

	/* 
	  3.对象存值   用点语法  （一定要保障存的属性 在对象里面不存在）
	 */
	obj2.number = "001"
	console.log(obj2);

	// function   函数
	/* 
	  1.定义函数   function name(){}
	 */
	function fn1() {
		console.log("我是fn1函数");
	}

	/* 
	  2.函数的使用   name()
	 */
	fn1()
	/* 
	  3.函数的参数   function name(a,b) {}  a,b叫做函数的形参
	                 name(1,2)    1,2 叫做函数的实参
	 */

	// function sum(){
	// 	let a = 1;
	// 	let b = 2;
	// 	console.log(a+b);
	// }

	// sum()

	function sum(num1, num2) {
		console.log(num1 + num2);
	}

	sum(1212, 1)

	/* 
	 4.函数的返回值  return  代表了函数的执行的结果 
	 
	 */

	console.log(sum(1, 2)); //  undefined  表示函数没有执行结果  因为 没有  return

	function num(a, b) {
		
		console.log(  a * b );
		return  a*b
	}



	console.log(num(2, 10));


	export default {
		data() {
			return {

			}
		},
		methods: {

		}
	}
</script>

<style>

</style>