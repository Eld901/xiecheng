<template>
	<view>
		<!-- 
		   1.v-bind  绑定数据  简写   组件上   :属性="变量"
			                        组件里    {{变量}}
									
		   2.v-on   绑定事件   简写  @
		     事件：
			  1.事件源
			  2.事件     @click="函数名"
			  3.事件处理函数 
			  
			  
			3.v-for  列表循环   v-for="(item,index) in 数组"
			  item 代表循环的数组里面的每一项数据
			  index 代表循环的数组的下标
			  
			  
			4.v-if  条件渲染   v-if="变量"
		 -->
		 
		 
		 
		 <!--
		  v-if="变量"
		  v-else -->
		 <view v-if="istrue">我是为真的结果</view>
		 <view v-else>我是为假的结果</view>
	</view>
</template>

<script>
	
	export default {
		data() {
			return {
				istrue:0
			}
		},
		methods: {
			
		}
	}
</script>

<style>

</style>
