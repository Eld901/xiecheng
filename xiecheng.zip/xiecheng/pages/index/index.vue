<template>
	<view>
		<view class="general" >
			<view class="in" >
				<input type="text" value="欢迎使用携程app">
			</view>
			
			<navigator url="../demo1/demo1" open-type="switchTab">
				<view class="btn1">立即体验</view></navigator>
			
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				ipt:""
			}
		},
		methods: {
			clear() {
				let getipt =this.ipt;
				this.ipt = "";
			}
		}
	}
</script>

<style>
	
	.general {
		
		height: 667px;
		background-color: #1e77eb;
		background-image:url("/static/5.jpg");
		background-repeat: no-repeat;
		background-size: 100%;
		background-position:bottom;
	}
	.in {
		height: 44px;
		background-color: #e8f4ff;
		display: flex;
		align-items: center; //垂直居中
		padding-left: 15px;
		color:#1e77eb;
		font-weight: 700;
		
	}
	
	.btn1 {
		width: 200px;
		height: 35px;
		background-color:#ffffff;
		border-radius: 10px;
		text-align: center;
		line-height: 35px;
		font-weight: 700;
		font-size: 25px;
		margin: auto;
		margin-top: 250px;
		color: #1e77eb;
	}
	
	

</style>
