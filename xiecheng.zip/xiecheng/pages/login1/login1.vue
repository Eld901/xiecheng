<template>
	<view>
		
		
		<view class="container1">
			<navigator url="../login/login" open-type="switchTab">
				<image src="/static/message/返回.png" mode="" class="return"></image>
			</navigator>
			<view class="title"></view>
		</view>
		
		<view class="all">
	<!-- 标题 -->
			<view class="bx">
			<view class="title">手机快捷登录</view>
			</view>
	
			<view class="bx1">
				<!-- 手机号登录 -->
				<view class="bxa">
					<view class="lg1">
					  <input type="text" class="font_1" @input="onInput" placeholder="请输入手机号" v-model="phoneNumber">
					</view>
					<!-- svg画线 -->
					<view style="height: 1px;">
						<svg xmlns="http://www.w3.org/2000/svg" version="1.1">
						  <line x1="0" y1="0" x2="400" y2="0" style="stroke:rgb(0,0,0);stroke-width:0.2" />
						</svg>
					</view>
				</view>
				<!-- 密码输入 -->
				<view class="bxa">
					<view class="lg2">
					  <input type="text" password="true" class="font_1" @input="onInput"  placeholder="请输入密码" v-model="phonePassword">
					</view>
					<!-- svg画线 -->
					<view style="height: 1px;">
						<svg xmlns="http://www.w3.org/2000/svg" version="1.1">
						  <line x1="0" y1="0" x2="400" y2="0" style="stroke:rgb(0,0,0);stroke-width:0.2" />
						</svg>
					</view>
				</view>
				<!-- 登录按钮 -->
				<view class="bt">
					<navigator url="../login/login" open-type="switchTab">
					<button class="button" @click="onSubmit">登 录</button>
				</navigator>
				</view>
		  </view>
		  <!-- 底部 -->
			<view class="bx2">
				<view class="dx">短信验证码登录</view>
				<view class="zh">找回密码</view>
			</view>
		  
			<view class="bx3">
				<image src="../../static/login/qq (1).png"mode="heightFix" class="im1"></image>
				<image src="../../static/login/baidu.png"mode="heightFix" class="im2"></image>
				<image src="../../static/login/微博.png"mode="heightFix" class="im3"></image>
			</view>
			<view class="ra">
				<label class="radio"><radio value="r1" checked="true" />阅读并同意携程的<服务协议>和<个人信息保护政策></label>
			</view>
		</view>
		
		
    </view>
</template>
 
<script>
export default {
		data() {
			return {
				
			}
		},
		// 方法
		methods: {
				
			}
		}
	</script>
					
<style>
	.all{
			width: 98%;
			margin-left:1%;
	}
	.container1 {
		width: 100%;
		height: 44px;
		
		display: flex; //放在水平主轴上
		align-items: center; //垂直居中
		justify-content: center;
		position: fixed;
	}
	
	.return {
		width: 22px;
		height: 22px;
		
		position: absolute;//控制return返回键相对于模拟器顶部和左部的位置
		top:13px;
		left:11px;  
	}
	.title {
		font-size: 17px;
	}
	
    .bx{
		justify-content: center;
		width: 100%;
		height: 120px;
}

.title{
	text-align: center;
	height: 46px;
	font-size: 23px;
	line-height: 60px;
	justify-content: center;
	margin-top: 50px;
	color: #000;
}

.bx1{
		justify-content: center;
		width: 100%;
		height: 160px;
}

.bxa{
		justify-content: center;
		width: 100%;
		height: 50px;
}

.bt{
		justify-content: center;
		margin-top: 10px;
		width: 100%;
		height: 50px;
}


.button{
	width: 100%;
	height: 40px;
	background-color:#eeeeee;
	color:#999999;
}

.bx2{
	    display: flex;
		justify-content:space-between;
		width: 100%;
		height: 120px;
		color:#757575;
}

.bx3{
	    display: flex;
		justify-content:space-between;
		width:80%;
		margin-left:10%;
		height: 30px;
}

.im1 {
		width: 20px;
		height: 25px;
	}
	
.im2 {
		width: 20px;
		height: 25px;
	}
	
.im3 {
		width: 20px;
		height: 25px;
	}
	
.ra{
	align-items: center;
			justify-content: center;
			margin-top: 10px;
			width: 100%;
			height: 50px;
	}
	
.radio{
	align-items: center;
			justify-content: center;
			margin-top: 8px;
			width: 60%;
			height: 50px;
			font-size: 5px;
			color:#999999;
	}
					
</style>
					
