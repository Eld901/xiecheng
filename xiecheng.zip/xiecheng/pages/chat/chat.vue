<template>
	<view >
		
		
		<view class="container2">
			<scroll-view scroll-y="true" class="chatbg" :scroll-top="position" >
			<view >
			<view class="chatgroup">
				<view class="toptext">您好，很高兴为您服务。把您的问题告诉我，我会竭力为您解答</view>
				
				<view class="chatlist" v-for="(item,index) in chatarr">
					<view class="mymsg" v-if="item.ismine">
						<view class="mytext">
							<view class="myname">me</view>
							<view class="mywords">{{item.msg}}</view>
						</view>
						<image src="" mode="" class="myhd"></image>
					</view>
					
					<view class="youmsg" v-else>
						<image src="/static/message/6hd.jpg" mode="" class="youhd"></image>
						<view class="youtext">
							<view class="youname">当地向导西双版纳徐磊</view>
							<view class="youwords">{{item.msg}}</view>
						</view>
					</view>
				</view>
				
			</view>
			</view>
		</scroll-view>
		</view>
		
		<view class="container1">
			<view class="left">
				<navigator url="../message/message" open-type="switchTab">
				<image src="/static/message/返回.png" mode="" class="return"></image>
				</navigator>
			</view>
			<view class="center">
				<view class="title">徐磊和Ta的团队</view>
			</view>
			<view class="right">
				<image src="/static/message/进店.png" mode="" class="intoshop"></image>
			</view>
		</view>
		
		<view class="container3">
			<view class="iptbox">
				<input type="text" class="ipt" v-model="myipt">
				<image src="/static/message/emoji.png" mode="" class="emoji"></image>
			</view>
			<view class="sendbox" @click="send">
				<image src="/static/message/send.png" mode="" class="send" ></image>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				myipt:"",
				chatarr: [
					// {
					// 	ismine:1,
					// 	msg:"hahh"
					// },
					// {
					// 	ismine:0,
					// 	msg:"ehehehh"
					// },
				],
				position:''
				
			}
		},
		methods: {
			send() {
				let getipt = this.myipt;
				this.myipt = "";
				let myinput = {
					ismine:1,
					msg:getipt
				}
				this.chatarr.push(myinput);
				this.position = (this.chatarr.length+1-9)*50.2
				// this.position =this.chatarr.length+10000
				
				
				let that = this
				uni.request({
					url: "/api",
					method: "GET",
					data: {
						key: "free",
						appid: 0,
						msg: getipt
					},
					success(res) {
						console.log(res.data.content);
						let youinput = {
							ismine: 0,
							msg: res.data.content
						}
						that.chatarr.push(youinput)
						that.position = (this.chatarr.length+1-9)*50.2
					}
				})
				
			}
		}
	}
</script>

<style>
	.container1 {
		width: 100%;
		height: 49px;
		display: flex;
		justify-content: space-between;
		align-items: center;
		position: fixed;
		background-color:#fff;
	}
	.left {
		width: 24px;
		height: 24px;
		margin-left: 10px;
		text-align: center;
	}
	.return {
		width: 22px;
		height: 22px;
	}
	.center {
		width: 60%;
		height: 25.5px;
		display: flex;
		align-items: flex-end;
	}
	.title {
		font-size: 17px;
		max-width: 73%;
		height: 25.5px;
		line-height: 25.5px;
		text-align: center;
		color: #333;
		margin: auto;
	}
	.right {
		width: 32px;
		height: 32px;
		margin-right: 8px;
	}
	.intoshop {
		width: 32px;
		height: 32px;
	}
	.container2 {
		position: absolute;
		top: 49px;
		width: 100%;
	}
	.bgcolor {
		background-color: ;
	}
	.chatbg {
		background-color: #f0f1f2;
	}
	.chatgroup {
		padding: 0 16px;
		height: 515.2px;
	}
	.toptext {
		width: 257.2px;
		height: 34px;
		padding:0 43px;
		margin-bottom: 8px;

		text-align: center;
		font-size: 13px;
		color: #939394;
		position: relative;
		top:5px;
	}
	
	.mymsg {
		display: flex;
			justify-content: end;
	}
	.myhd {
		width: 35px;
		height: 35px;
		border-radius: 50%;
		background-color: #fff;
	}
	.mytext {
		text-align: end;
		padding-right: 10px;
	}
	.myname {
		font-size: 12px;
		color: #676b73;
	}
	.mywords {
		margin-top: 5px;
		padding: 5px 5px;
		border-radius: 5px;
		background-color: white;
		color: #333;
		font-size: 14px;
	}
	
	.youmsg {
		display: flex;	
	}
	.youhd {
		width: 35px;
		height: 35px;
		border-radius: 50%;
		background-color: #fff;
	}
	.youtext {
		padding-left: 10px;
	}
	.youname {
		font-size: 12px;
		color: #676b73;
	}
	.youwords {
		margin-top: 5px;
		padding: 5px 5px;
		border-radius: 5px;
		background-color: white;
		color: #333;
		font-size: 14px;
	}
	
	.container3 {
		width: 100%;
		background-color: #f5f6f7;
		height: 53px;
		padding-left: 12px;
		display: flex;
		align-items: center;
		position: fixed;
		bottom: 50px;
	}
	.iptbox {
		width: 313.2px;
		height: 38px;
		display: flex;
	}
	.ipt {
		width: 258.2px;
		height: 26px;
		padding: 6px 5px 6px 12px;
		background-color:#fff;
		color: #757575;
		font-size: 14px;
	}
	.emoji {
		width: 38px;
		height: 38px;
	}
	.sendbox {

		height: 30px;
		margin: 0 7px;
	}
	.send{
		width: 30px;
		height: 30px;
		background-color: #fff;
	}


</style>
