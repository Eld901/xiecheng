<template>
	<view >
		<view class="container1">
				<navigator url="../message/message" open-type="switchTab">
				<image src="/static/message/返回.png" mode="" class="return"></image>
				</navigator>
				<view class="toptitle">订单出行</view>
		</view>
		
		<view class="container2">
			<view class="itembox" v-for="(item,index) in itmarr">
				<view class="title">{{item.title}}</view>
				<view class="time">{{item.time}}</view>
				<view class="content">{{item.content}}</view>
				<navigator url="../detail/detail">
				<view class="detail" v-if="item.tdetail">查看详情</view>
				</navigator>
			</view>
			
			<view class="nomore">
				———— 没有更多内容了 ————
			</view>
		</view>
		
		<view class="container3">
			
			<view class="btmleft">
				我的订单
			</view>
			<navigator url="../chat/chat" open-type="switchTab">
			<view class="btmright">
				联系客服
			</view>
			</navigator>
		</view>
		
	</view>
</template>

<script>
	export default {
		data() {
			return {
				itmarr:[
					{
						id:0,
						tdetail:0,
						title:"火车票退票成功通知",
						time:"04-27 23:09",
						content:"4月29日，K529南充-成都东，退票成功，退款将于5月7日前退至您的原支付账户。如您已将车票(报销凭证)取出，请在180天内携带购票证件原件至车站办理退款，同时交回车票(报销凭证)。"
					},
					{
						id:1,
						tdetail:1,
						title:"火车票退票成功通知",
						time:"04-27 23:08",
						content:"4月29日，K529，南充-成都，退票成功。退票金额将于5月7日前退至您原支付账户。"
					},
					{
						id:2,
						tdetail:0,
						title:"改签失败通知",
						time:"04-23 09:18",
						content:"抱歉，南充-成都东改签失败。坐席已无票"
					},
					{
						id:3,
						tdetail:0,
						title:"火车票改签成功通知",
						time:"04-23 09:15",
						content:"改签成功，新车票为4月29日南充-成都东K529，硬座03车厢083号"
					},
					{
						id:4,
						tdetail:0,
						title:"火车票购票失败通知",
						time:"04-18 19:11",
						content:"抱歉，5月2日成都东-南充K788，5月2日成都东-南充K788购票失败。抱歉，组合坐席连坐失败暂无法购票，已取消，请稍后重新下单，携程将继续为您购票~"
					}
				]
			}
		},
		methods: {
			
		}
	}
</script>

<style>
	.container1 {
		width: 100%;
		height: 44px;
		display: flex; 
		align-items: center; 
		justify-content: center;
		position: fixed;
	}
	.return {
		width: 22px;
		height: 22px;
		position: absolute;
		top:13px;
		left:11px;  
	}
	.toptitle {
		font-size: 17px;
	}
	
	.container2 {
		width: 343.2px;
		height: 927.4px;
		padding: 8px 16px 0 16px;
		background-color: #f8f8f8;
		
		
		position: absolute;
		top:44px;
		
	}
	.itembox {
		width: 319.2px;
		padding: 12px;
		margin-bottom: 8px;
		background-color: white;
		
	}
	.title {
		width: 319.2px;
		height: 20px;
		font-size: 15px;
		font-weight: 600;
		color: #000;
	}
	.time {
		height: 17px;
		margin-top: 4px;
		font-size: 12px;
		color: #999;
	}
	.content {
		width: 319.2px;
		margin-top: 4px;
		font-size: 14px;
		color: #666;
	}
	.detail {
		height: 16px;
		font-size: 15px;
		padding-top:12px ;
		border-top: 0.8px;
		margin-top: 12px;
		color: #0086f6;
		text-align: end;
		line-height: 16px;
		border-top: 1px solid #eee;
	}
	.nomore {
		height: 32px;
		font-size: 13px;
		text-align: center;
		color: #a1a1a1;
	}
	
	
	.container3 {
		height: 53px;
		position: fixed;
		bottom: 0;
		display: flex;
		align-items: center;
		background-color: #fff;
		border-top: 1px solid #ebeced;
	}
	.btmleft {
		width: 187.2px;
		height: 33px;
		border-right: 0.8px;
		text-align: center;
		line-height: 33px;
		font-size: 14px;
		border-right: 1px solid #ebeced;
	}
	.btmright {
		width: 187.2px;
		height: 33px;
		text-align: center;
		line-height: 33px;
		font-size: 14px;
	}
	

</style>
