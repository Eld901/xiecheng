<template>
	<view>
		<view class="container1">
				<navigator url="../message/message" open-type="switchTab">
				<image src="/static/message/返回.png" mode="" class="return"></image>
				</navigator>
				<view class="title">账户通知</view>
		</view>
		
		<view class="c3">
		<image src="/static/interaction/img.png" mode="" class="img"></image>
		<view class="txt">暂无内容</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			}
		},
		methods: {
			
		}
	}
</script>

<style>
	.container1 {
		width: 100%;
		height: 44px;
		
		display: flex; //放在水平主轴上
		align-items: center; //垂直居中
		justify-content: center;
		position: fixed;
	}
	
	.return {
		width: 22px;
		height: 22px;
		
		position: absolute;//控制return返回键相对于模拟器顶部和左部的位置
		top:13px;
		left:11px;  
	}
	.title {
		font-size: 17px;
	}
	
	.c3 {
		padding: 0 102.5px;
		height: 667px;
		display: flex;
		flex-direction: column;
		align-items: center;
		justify-content: center;
		background-color: #f8f8f8;
	}
	.img {
		width: 170px;
		height: 170px;	
	}
	.txt {
		width: 60px;
		height: 22.5px;
		font-size: 15px;
		color: rgb(51, 51, 51);
	}

</style>
