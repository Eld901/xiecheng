module.exports = {
  devServer: {
    proxy: {
      '/api': {
        target: 'http://api.qingyunke.com/api.php',
        changeOrigin: true,
		pathRewrite: {
		          '^/api': ''
		        }
      }
    }
  }
}